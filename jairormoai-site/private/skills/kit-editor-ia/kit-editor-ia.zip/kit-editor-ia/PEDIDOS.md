# Pedidos listos · Kit Editor IA

Cópialos, pégalos en Claude junto con tu video y ajústalos a tu gusto.

## Reels y TikTok
- Edítame este video: quita pausas y tomas repetidas, ponle subtítulos palabra por palabra y un gancho fuerte al inicio.
- Hazlo más dinámico: corta cualquier pausa de más de 0.3 segundos.
- Dame 3 versiones del mismo video con 3 ganchos distintos.
- Pon la palabra más fuerte del video detrás de mí.

## Anuncios
- Edítalo para anuncio: subtítulos en caja blanca y gancho en los primeros 2 segundos. Avísame si alguna frase puede ser rechazada por Meta.
- Quita la parte donde digo el precio y deja todo lo demás igual.

## Clases y tutoriales
- Corta solo las pausas largas (más de 0.6 segundos) y haz un checklist con los pasos que voy diciendo.
- Ponle subtítulos al centro y en mayúsculas.

## Escenario
- Recórtame y ponme este fondo: [arrastra la imagen].
- Desenfoca el fondo como si fuera modo retrato.

## Estilo
- Edítalo igual que este Reels: [arrastra el video de referencia].
- Ponle música suave que baje cuando hablo: [arrastra la pista].
