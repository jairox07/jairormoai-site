# Kit Editor IA · jairoromo.ai · instalador para Windows 10/11
# Uso: powershell -ExecutionPolicy Bypass -File instalar.ps1
$ErrorActionPreference = "Stop"
$env:PYTHONUTF8 = "1"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Dir     = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest    = Join-Path $env:USERPROFILE ".claude\skills"
$HomeKit = Join-Path $env:USERPROFILE ".kit-editor-ia"

Write-Host "== Kit Editor IA - instalacion =="
Write-Host "-> 1/4 Copiando los 11 editores y el modo guiado a $Dest"
New-Item -ItemType Directory -Force -Path $Dest, $HomeKit | Out-Null
Get-ChildItem (Join-Path $Dir "skills") -Directory | ForEach-Object {
  $t = Join-Path $Dest $_.Name
  if (Test-Path $t) { Remove-Item $t -Recurse -Force }
  Copy-Item $_.FullName $t -Recurse
  Write-Host "   OK /$($_.Name)"
}
Copy-Item (Join-Path $Dir "skills\editor-ia\kit.sh") (Join-Path $HomeKit "kit") -Force

function Refresh-Path { $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User") }
$hasWinget = [bool](Get-Command winget -ErrorAction SilentlyContinue)

Write-Host "-> 2/4 Revisando ffmpeg y Python"
if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
  if (-not $hasWinget) { Write-Host "Falta winget. Actualiza 'Instalador de aplicacion' desde Microsoft Store y vuelve a correr esto."; exit 1 }
  winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements | Out-Host
  Refresh-Path
}

# Busca un Python 3.10+ real (evita el acceso directo de Microsoft Store)
function Find-Py {
  foreach ($v in @("3.13","3.12","3.11","3.10")) {
    try { $p = & py "-$v" -c "import sys;print(sys.executable)" 2>$null; if ($LASTEXITCODE -eq 0 -and $p) { return $p.Trim() } } catch {}
  }
  try { $p = & python -c "import sys;print(sys.executable if sys.version_info>=(3,10) else '')" 2>$null; if ($p -and $p.Trim()) { return $p.Trim() } } catch {}
  return $null
}
$py = Find-Py
if (-not $py) {
  if (-not $hasWinget) { Write-Host "Falta Python 3.12: instalalo desde python.org (marca 'Add python.exe to PATH')."; exit 1 }
  Write-Host "   instalando Python 3.12..."
  winget install --id Python.Python.3.12 -e --accept-source-agreements --accept-package-agreements | Out-Host
  Refresh-Path
  $py = Find-Py
  if (-not $py) { Write-Host "Python quedo instalado pero esta terminal no lo ve. Cierra y abre Claude Code y corre el instalador otra vez."; exit 1 }
}
Write-Host "   OK Python: $py"

Write-Host "-> 3/4 Creando el entorno del kit (tarda 2-5 min la primera vez)"
$venv = Join-Path $HomeKit "venv"
& $py -m venv $venv
$vpy = Join-Path $venv "Scripts\python.exe"
& $vpy -m pip install --upgrade pip -q
& $vpy -m pip install -q faster-whisper "rembg[cpu]" pillow numpy
if ($LASTEXITCODE -ne 0) { Write-Host "Fallo la instalacion de paquetes de Python. Revisa tu internet y vuelve a correr."; exit 1 }

Write-Host "-> 4/4 Revision final"
& $vpy (Join-Path $Dest "editor-ia\scripts\revisar.py")
Write-Host ""
Write-Host "Listo. Si ffmpeg aparece con X, cierra y vuelve a abrir Claude Code. Luego arrastra tu video y escribe: 'Editame este video'."
