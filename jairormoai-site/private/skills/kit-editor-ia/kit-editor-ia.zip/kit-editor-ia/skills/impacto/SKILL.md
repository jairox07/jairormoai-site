---
name: impacto
description: Pone una palabra gigante DETRÁS de la persona, entre el fondo y su cuerpo. Úsalo con /impacto, /texto-atras o cuando pidan "pon la frase fuerte detrás de mí" o "palabra de impacto".
---

# /impacto · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

1. Elige UNA palabra fuerte (máximo 8 letras) que el usuario diga en el video.
2. `bash ~/.kit-editor-ia/kit textos impacto P.json --palabra "GRATIS" --y 0.25 --dur 1.4` (la palabra aparece justo cuando la dice; `--y` es la altura y debe ir por encima de los hombros).
3. `bash ~/.kit-editor-ia/kit fondo VIDEO --fondo blur --detras capa_impacto.ass`
4. Quema los subtítulos al final, encima de todo.
