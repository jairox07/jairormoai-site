---
name: referencia
description: Crea un estilo propio a partir de un video o un link que le guste al usuario (Reels, TikTok, Shorts) y lo guarda para reusarlo. Úsalo con /referencia, /estilo propio, o cuando digan "edítalo como este video", "con el mismo estilo", "quiero mi propio estilo" o peguen un link de un video que les gusta.
---

# /referencia · tu propio estilo · Kit Editor IA v2

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md y la sección **Estilos v2** si no lo has hecho en esta conversación).

**Se copia el estilo, no el contenido:** tipografía, colores, ritmo, dónde van los textos, qué efectos usa. Nunca reutilices el video, la voz, los logos ni la marca del creador de la referencia.

## 1. Conseguir el video de referencia
- **Si lo arrastró** al chat o te dio la ruta: úsalo directo.
- **Si pegó un link**: `bash ~/.kit-editor-ia/kit descargar "<link>" --salida referencia.mp4`
  - Si falla (Instagram suele pedir sesión): pide que lo guarde o haga una grabación de pantalla y la arrastre. Una grabación de pantalla sirve igual.
- Si solo da el nombre de una cuenta, pide un video concreto (el link de un Reel).

## 2. Estudiarlo
1. `bash ~/.kit-editor-ia/kit analizar referencia referencia.mp4 --cuadros 16` → ritmo (segundos por toma) + hoja de cuadros.
2. Saca además la apertura con detalle (los primeros 3 s deciden todo):
   `ffmpeg -v error -y -t 3 -i referencia.mp4 -vf "fps=4,scale=270:-2,tile=6x2:padding=4:color=white" -frames:v 1 referencia.apertura.jpg`
3. Lee las dos hojas (Read) y anota:
   - **Subtítulos**: fuente (condensada, redonda, serif, cursiva), tamaño, mayúsculas, palabras por bloque, posición, contorno o caja, color de la palabra activa o de las clave.
   - **Textos grandes**: ¿hay palabras gigantes?, ¿detrás de la persona?, ¿metálicas o de color?
   - **Elementos**: íconos, stickers, tarjetas, etiquetas, imágenes, CTA.
   - **Movimiento**: zooms, transiciones (destello, flash, cortes secos), B-roll.
   - **Color**: cálido o frío, contraste, viñeta.

## 3. Convertirlo en un estilo del kit
1. Elige la plantilla más parecida de `~/.claude/skills/editor-ia/estilos/` y cópiala a `~/.kit-editor-ia/estilos/mio-<nombre-corto>.json` (crea la carpeta si no existe).
2. Cambia `id` (igual al nombre del archivo), `nombre` ("Mi estilo · <nombre>"), `descripcion` y los bloques `subtitulos`, `titulo`, `acento`, `icono`, `tarjeta`, `color`, `portada` y `estructura` para que se parezcan a la referencia. Las opciones están en la sección **Estilos v2** de `editor-ia`.
3. Tipografías: usa solo las del kit (`editor-ia/fonts`) y elige la más cercana:
   - Condensada fuerte → Anton
   - Redonda pesada de caricatura → Luckiest Guy
   - Geométrica moderna → Montserrat (Medium, Bold, ExtraBold, Black) o Poppins
   - Limpia de lectura → Inter
   - Serif cursiva elegante → Playfair Display Italic
   - Tecnológica → Exo 2
4. Mantén siempre la estructura del kit: B-roll inicial, texto detrás al abrir y cerrar, íconos o imágenes en lo importante.

## 4. Mostrarlo y guardarlo
1. Renderiza una **muestra** con el video del usuario: 3 cuadros (apertura, una clave y el cierre) con `motor --desde/--hasta` y una hoja de cuadros. Enséñasela antes de editar todo.
2. Ajusta con lo que diga ("letra más grande", "sin cursiva").
3. Confirma: "Guardé tu estilo como «mio-<nombre>». La próxima vez solo di «edítalo con mi estilo <nombre>»".
