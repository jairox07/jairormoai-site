---
name: referencia
description: Copia el ritmo y estilo de un Reels que le gusta al usuario. Úsalo con /referencia o cuando digan "edítalo como este video" o "con el mismo estilo".
---

# /referencia · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

1. `bash ~/.kit-editor-ia/kit analizar referencia ref.mp4` te da los cortes por segundo, la duración media de cada toma y una hoja de cuadros.
2. Mira la hoja y describe en 3 líneas: estilo de subtítulos (tamaño, posición, mayúsculas, palabras por bloque), si tiene gancho en pantalla, colores y ritmo.
3. Traduce eso a parámetros: `--pausa` según los segundos por toma, `--estilo`, `--palabras-por-bloque`, `--posicion` y si lleva gancho.
4. Edita el video del usuario con esos parámetros, con su voz y su marca. No copies logos ni marcas de la referencia.
