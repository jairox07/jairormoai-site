---
name: gancho
description: Pone un gancho grande en pantalla en los primeros segundos. Úsalo con /gancho o cuando pidan "abre con un gancho", "frase grande al inicio" o "versiones con distintos ganchos".
---

# /gancho · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

1. Si no te dan el texto, propón 3 ganchos de máximo 6 palabras sacados de la transcripción: curiosidad, número concreto, o contradicción.
2. `bash ~/.kit-editor-ia/kit textos gancho P.json --texto "TU GANCHO" --dur 2.6`
3. Quema junto con los subtítulos: `quemar.py VIDEO capa_gancho.ass capa_subs.ass`
4. Si pide versiones, genera un .ass por gancho y entrega `VIDEO.v1.mp4`, `.v2`, `.v3`.
