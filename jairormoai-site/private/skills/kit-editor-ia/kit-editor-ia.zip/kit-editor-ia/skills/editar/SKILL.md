---
name: editar
description: Modo guiado del Kit Editor IA. Úsalo con /editar o cuando el usuario mande un video y diga algo vago como "edítame esto", "no sé qué pedir" o "ayúdame a editarlo". Hace pocas preguntas con opciones y luego edita.
---

# /editar · modo guiado · Kit Editor IA

Parte del Kit Editor IA. El editor principal es `editor-ia`: lee su SKILL.md si no lo has leído en esta conversación y úsalo para todo el trabajo técnico.

## Regla de oro: no estorbes
- Si el usuario ya dijo QUÉ quiere ("quita las pausas y ponle subtítulos"), **no preguntes nada**: edita directo con `editor-ia`.
- Pregunta solo lo que falta, máximo 3 preguntas en total, todas juntas en una sola vez (con AskUserQuestion si existe; si no, en texto con opciones numeradas). Nunca hagas un cuestionario largo.
- Si el usuario contesta "tú decide" o "lo que sea", elige lo mejor para ese tipo de video y sigue sin volver a preguntar.
- Antes de preguntar, revisa si ya hay un video: si no lo hay, pídelo y espera.

## Las preguntas (solo las que apliquen)
1. **¿Para qué es?** Reel o TikTok · Anuncio · Clase o tutorial · Otro.
   (Define el ritmo: anuncios y Reels más rápido; clases con pausas más largas.)
2. **¿Qué le pongo?** (se puede elegir varias) Subtítulos palabra por palabra · Gancho en pantalla al inicio · Música · Solo cortar pausas y errores.
3. **¿Gancho?** Si eligió gancho y no dio texto: propón 3 opciones de máximo 6 palabras sacadas de lo que dijo, y que elija una o escriba la suya.
4. Solo si pidió fondo o texto detrás de él: pide la imagen de fondo o la palabra.

## Después de contestar
1. Repite en UNA línea lo que vas a hacer ("Cortar pausas, subtítulos en caja y gancho: «…». ¿Va?") solo si hubo más de una decisión tuya; si no, sigue.
2. Edita con el flujo estándar de `editor-ia` (transcribir → planear → aplicar → capas → quemar → revisar).
3. Entrega: duración antes → después, qué quitaste, dónde quedó el archivo.
4. Cierra con UNA oferta concreta de ajuste, por ejemplo "¿Probamos el gancho más grande o con otro texto?". Si dicen que sí, ajusta sin repetir todo el flujo.

Nunca publiques nada. Tú editas, el usuario publica.
