---
name: editar
description: Asistente guiado del Kit Editor IA v2. Úsalo con /editar o cuando el usuario mande un video y diga algo vago como "edítame esto", "no sé qué pedir", "ayúdame a editarlo" o "quiero que se vea profesional". Lo lleva de la mano - estilo (con imágenes de muestra), su propio estilo desde un video o link, B-roll, texto detrás, íconos, transiciones, zooms y cierre - y luego edita.
---

# /editar · asistente guiado · Kit Editor IA v2

Parte del Kit Editor IA. El editor principal es `editor-ia`: lee su SKILL.md (sobre todo la sección **Estilos v2**) si no lo has leído en esta conversación, y úsalo para todo el trabajo técnico.

## Reglas de oro
- **No estorbes.** Si el usuario ya dijo qué quiere ("estilo Cine Premium, corta pausas"), no preguntes: edita.
- **Pregunta en rondas cortas**, con opciones y la recomendada primero (con AskUserQuestion si existe; si no, en texto con opciones numeradas). Máximo 3 rondas en total.
- **Siempre hay salida rápida:** "Usa lo recomendado" en cada ronda. Si dice "tú decide", decide y sigue sin volver a preguntar.
- Antes de preguntar, revisa si ya hay un video. Si no, pídelo y espera.
- Mientras el usuario contesta, ya puedes ir transcribiendo el video (paso 1 del flujo).

## Ronda 1 · ¿Cómo quieres empezar?
1. **Muéstrale el catálogo** de estilos: abre la imagen para que la vea
   - Windows (Git Bash): `start "" "$HOME/.claude/skills/editor-ia/estilos/catalogo.jpg"`
   - Mac: `open "$HOME/.claude/skills/editor-ia/estilos/catalogo.jpg"`
   y léela tú también (Read) para poder describirla. Las muestras sueltas están en `estilos/muestras/`.
2. Pregunta **¿Cómo quieres empezar?**
   - **Con un estilo del catálogo**: Cine Premium (1), Notificación (2), Negocios Bold (3), Podcast Minimal (4), Reto / Energía (5), Explicador (6), Neón de marca (7). Si no sabe, recomienda según el tipo de video: anuncio → 1 o 3; tutorial → 6 o 2; opinión o negocio → 3; entrevista → 4; reto o entretenimiento → 5; marca personal → 7.
   - **Con los colores de mi marca**: "¿Cuáles son los colores de tu marca (principal y secundario) y tienes tipografía propia?". Corre `kit marca` (skill `/referencia`, sección «tu estilo de marca»): tiene las mismas animaciones del kit pintadas con su paleta.
   - **Con mi propio estilo**: "¿Tienes un video que te guste? **Arrástralo aquí o pega el link** (Reels, TikTok, Shorts) y armo tu estilo a partir de él". Sigue la skill `/estilo`. Si ya creó estilos antes, ofrécelos (están en `~/.kit-editor-ia/estilos/`).
   - **Libre**: solo cortes y subtítulos, como siempre, sin plantilla.

## Ronda 2 · Lo que lleva el video (todo viene marcado con lo recomendado)
Pregunta junto, en una sola ronda:
1. **¿Para qué es?** Reel o TikTok · Anuncio · Tutorial o clase · Pódcast o entrevista. Esto define el ritmo de cortes.
2. **B-roll al inicio** (recomendado): "¿Tienes un clip o foto para abrir? (tu producto, tu negocio, una captura). Arrástralo aquí. Si no, hago una portada animada con tu gancho".
3. **Imágenes en momentos clave** (opcional): capturas, logos o fotos de producto, y en qué palabra aparecen ("la captura cuando digo «app»").
4. **Sonidos sutiles**: "¿Quieres sonidos sutiles cuando aparecen los títulos, íconos y transiciones? (apagados por defecto)". Sí · No (recomendado). Si dice que sí, se agregan al final con `sonidos.py`. Nunca los pongas sin que lo pida.
5. **Gancho y cierre**: propón 3 opciones de gancho (máximo 2 palabras gigantes detrás de él, sacadas de lo que dijo) y pregunta el llamado a la acción ("Comenta GUÍA", "Sígueme", "Link en mi perfil").

## Ronda 3 · Afinar (solo si el usuario quiere control; si no, salta)
- **Transiciones**: destello de luz · flash de color · cortes secos.
- **Zooms**: en palabras clave (recomendado) · ritmo constante (energía) · ninguno.
- **Íconos**: en lo importante (recomendado) · pocos · ninguno.
- **Texto detrás**: apertura y cierre (recomendado) · también en palabras clave · solo apertura.
- **Subtítulos**: los del estilo (recomendado) o cambiar posición, tamaño o color.
- **Música**: sí, con la música que traiga el usuario (baja sola cuando habla), o sin música.
- **Volumen de los sonidos** (solo si pidió sonidos): casi imperceptibles · sutiles (recomendado) · más presentes.

## Después de contestar
1. Repite en UNA línea el plan: "Cine Premium · B-roll con tu foto · gancho «OUTRO» detrás · íconos en 6 claves · cierre «TUTORIAL» + Comenta TUTORIAL. ¿Va?".
2. Edita con el flujo de **Estilos v2** de `editor-ia`: transcribir → cortar → `plan` → revisar el plan → **muestra** (3 cuadros clave renderizados) → aprobar → `motor` → revisar → entregar.
3. Entrega: duración antes → después, qué estilo y qué elementos puso, y dónde quedó el archivo.
4. Cierra con UNA oferta concreta: "¿Lo saco también en Negocios Bold para un anuncio?" o "¿Probamos el gancho «IA» en vez de «OUTRO»?".

Nunca publiques nada. Tú editas, el usuario publica.
