---
name: toma
description: Se queda con la mejor toma cuando el usuario repitió una frase. Úsalo con /toma o cuando digan "me equivoqué y lo repetí", "quédate con la última toma" o "la mejor toma".
---

# /toma · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

1. Transcribe y planea igual que /corte. `planear_cortes.py` marca solo las tomas repetidas (por defecto gana la última).
2. Revisa cada toma marcada en `quitadas`. Si el usuario dice "la primera salió mejor", invierte cuál se queda editando `keep`.
3. Si dudas entre dos tomas, saca un cuadro de cada una (`ffmpeg -ss T -frames:v 1`), míralos y elige por fluidez y energía. Explica por qué en una línea.
4. Aplica con `aplicar_cortes.py`.
