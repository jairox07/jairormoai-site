---
name: estilos
description: Muestra el catálogo de estilos del Kit Editor IA v2 con imágenes (Cine Premium, Notificación, Negocios Bold, Podcast Minimal, Reto / Energía, Explicador, Neón de marca) y los estilos propios del usuario. Úsalo con /estilos o cuando pregunten "qué estilos hay", "enséñame los estilos" o "cómo se ve cada uno".
---

# /estilos · catálogo · Kit Editor IA v2

Parte del Kit Editor IA (skill principal: `editor-ia`).

1. Abre el catálogo para que el usuario lo vea:
   - Windows (Git Bash): `start "" "$HOME/.claude/skills/editor-ia/estilos/catalogo.jpg"`
   - Mac: `open "$HOME/.claude/skills/editor-ia/estilos/catalogo.jpg"`
   Léelo tú también (Read) para poder comentarlo. Cada muestra suelta está en `estilos/muestras/NN-<estilo>.jpg`.
2. Lista los 7 estilos con una línea cada uno (el campo `descripcion` de cada `estilos/*.json`) y para qué tipo de video conviene.
3. Si hay estilos propios en `~/.kit-editor-ia/estilos/`, lístalos también ("Tus estilos: …").
4. Ofrece las tres salidas: "¿Con cuál edito tu video?", "¿Lo pinto con los colores y la tipografía de tu marca?" (`kit marca`, skill `/referencia`) o "¿Armamos tu propio estilo con un video o link que te guste?" (skill `/referencia`).

Todos los estilos traen la misma estructura: B-roll inicial, texto gigante detrás al abrir y al cerrar, íconos o imágenes en lo importante, zooms y transiciones. Lo que cambia es el diseño: tipografías, subtítulos, colores y elementos.

**Estilo propio = mismas animaciones.** Un estilo de marca o de referencia hereda de un estilo del kit (`base`): transiciones, destellos, flashes, escena de pasos y zooms vienen de fábrica; lo único que cambia son tus colores, tipografías y ritmo.
