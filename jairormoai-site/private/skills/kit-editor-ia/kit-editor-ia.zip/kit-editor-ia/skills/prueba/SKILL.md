---
name: prueba
description: Revisa una edición antes de entregarla y saca una hoja de cuadros. Úsalo con /prueba o cuando pidan "¿cómo quedó?", "revisa el video" o antes de cada entrega.
---

# /prueba · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

`bash ~/.kit-editor-ia/kit analizar prueba VIDEO.final.mp4 --cuadros 12`
Abre la hoja de cuadros y revisa: textos fuera de la zona segura (el 12% de arriba y el 20% de abajo los tapa la app), subtítulos encima de la boca, cortes que dejan una palabra a medias, gancho legible en el primer cuadro. Corrige y vuelve a revisar antes de entregar.
