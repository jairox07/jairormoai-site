---
name: subtitulos
description: Subtítulos sincronizados con la voz, palabra por palabra. Úsalo con /subtitulos o cuando pidan subtítulos, captions o letras.
---

# /subtitulos · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

Sobre un video ya cortado (usa `VIDEO.editado.palabras.json`):
- Karaoke, donde la palabra que dices se ilumina en magenta: `bash ~/.kit-editor-ia/kit textos subtitulos P.json --estilo karaoke --palabras-por-bloque 3`
- Bloque simple: `--estilo bloque` · Caja blanca para anuncios: `--estilo caja`
- Al centro de la pantalla: `--posicion centro` · Todo en mayúsculas: `--mayusculas`
Corrige en el JSON las palabras mal transcritas (nombres, marcas) ANTES de generar la capa. Después: `bash ~/.kit-editor-ia/kit quemar VIDEO.editado.mp4 capa.ass`.
