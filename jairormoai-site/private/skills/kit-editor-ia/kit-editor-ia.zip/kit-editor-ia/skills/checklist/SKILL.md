---
name: checklist
description: Checklist animado donde cada punto entra cuando lo dices. Úsalo con /checklist o cuando pidan "haz un checklist de lo que diga", "lista de pasos" o "enumera".
---

# /checklist · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

1. Lee la transcripción y saca de 3 a 5 puntos de máximo 4 palabras cada uno, usando las MISMAS primeras palabras que dice el usuario (así se sincronizan solos).
2. `bash ~/.kit-editor-ia/kit textos checklist P.json --item "Primero grabas" --item "Lo mandas a Claude" --item "Publicas"`
3. Quema: `quemar.py VIDEO capa_checklist.ass capa_subs.ass`. Si choca con los subtítulos, usa `--posicion abajo` en los subtítulos.
