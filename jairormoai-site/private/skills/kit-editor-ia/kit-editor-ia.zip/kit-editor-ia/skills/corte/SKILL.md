---
name: corte
description: Corta pausas, muletillas y errores de un video hablado. Úsalo con /corte o cuando pidan "quita las pausas", "córtalo", "quita la parte donde digo…".
---

# /corte · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

1. `bash ~/.kit-editor-ia/kit transcribir VIDEO`
2. `bash ~/.kit-editor-ia/kit planear_cortes VIDEO.palabras.json --pausa 0.45` (si pide "más dinámico" usa 0.3; para clases, 0.6). Para quitar una frase concreta agrega `--quitar "texto"`.
3. Lee `frases` y `quitadas` en el plan y corrige `keep` si se cortó una idea.
4. `bash ~/.kit-editor-ia/kit aplicar_cortes VIDEO VIDEO.plan.json --palabras VIDEO.palabras.json`
5. Reporta la duración antes → después y qué quitaste.
