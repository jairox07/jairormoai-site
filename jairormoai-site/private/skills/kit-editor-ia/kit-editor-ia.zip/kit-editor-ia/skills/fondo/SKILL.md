---
name: fondo
description: Quita el fondo del video sin pantalla verde y pone otro escenario (imagen, color o desenfoque). Úsalo con /fondo o cuando pidan "cambia el fondo", "recórtame" o "quita el fondo".
---

# /fondo · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

`bash ~/.kit-editor-ia/kit fondo VIDEO --fondo imagen.jpg` (o un color, `--fondo "#080610"`, o `--fondo blur`).
- Primero haz una prueba rápida con `--fps 15` sobre 3 s (`ffmpeg -t 3`) y muéstrala. La versión final va con el fps original.
- Avisa que tarda: de 1 a 3 s por cuadro en CPU.
- Haz este paso ANTES de quemar subtítulos (los subtítulos van encima).
