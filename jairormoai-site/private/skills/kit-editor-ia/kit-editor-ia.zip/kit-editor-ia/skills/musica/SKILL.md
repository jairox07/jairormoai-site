---
name: musica
description: Música de fondo que baja sola cuando hablas, y efectos de sonido sincronizados. Úsalo con /musica, /efectos o cuando pidan "ponle música", "un whoosh", "sonido cuando entra el texto".
---

# /musica · Kit Editor IA

Parte del Kit Editor IA (skill principal: `editor-ia`; lee su SKILL.md si no lo has leído en esta conversación). Trabaja sobre una copia del video y nunca sobrescribas el original.

`bash ~/.kit-editor-ia/kit musica VIDEO --musica pista.mp3 --volumen 0.22 --sfx whoosh.wav@0.0 --sfx pop.wav@3.2`
- Pide la pista al usuario (debe tener derechos de uso) o sugiere la biblioteca de audio de Instagram o TikTok al publicar.
- Pon los efectos en el mismo segundo en que entra cada texto (lee los tiempos en el .ass).
- Va al final, después de quemar los textos.
