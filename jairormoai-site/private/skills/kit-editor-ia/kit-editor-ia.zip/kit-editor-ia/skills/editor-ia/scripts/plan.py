"""Arma un plan de edición (borrador) para el motor de estilos, con la estructura del kit:

  1. B-roll inicial (tu clip o foto; si no hay, portada animada con el gancho)
  2. Texto gigante DETRÁS de ti al empezar (el gancho)
  3. Íconos, imágenes y acentos en las palabras clave, con zooms y transiciones
  4. Texto gigante DETRÁS de ti al cerrar + llamado a la acción

Uso:
  python plan.py video.editado.palabras.json --estilo cine-premium
         [--gancho "OUTRO"] [--cierre "TUTORIAL"] [--cta "Comenta TUTORIAL"]
         [--broll clip.mp4|foto.jpg|auto] [--imagen captura.png@palabra ...]
         [--claves "palabra1,palabra2"] [--sin-broll] [--salida plan.json]

El plan es un borrador: Claude lo revisa y lo ajusta (textos, tiempos, íconos) antes de renderizar.
"""
import argparse, json, os, re, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
ESTILOS = os.path.join(os.path.dirname(AQUI), "estilos")
PROPIOS = os.path.join(os.path.expanduser("~"), ".kit-editor-ia", "estilos")  # estilos que crea cada usuario

VACIAS = set("""a al algo algunos ante antes así aquí allá aun aunque bien cada como cómo con contra cual cuál cuando
de del desde donde dónde durante e el él ella ellas ellos en entre era eres es esa esas ese eso esos esta está están
estas este esto estos estoy fue fui ha han has hay he hoy la las le les lo los más me mi mis mucho muy nada ni no nos
nosotros o os otra otro para pero poco por porque pues que qué quien quién se sea ser si sí sin sobre solo sólo son su
sus también tan tanto te tengo tiene tienen todo todos tu tú tus un una uno unos unas va van vamos voy y ya yo
oigan oye bueno entonces tipo cosa cosas forma manera hacer hice hago puedo puedes quiero quieren estaba estaban
había habían tenía tener decir dije dice creo vale súper así""".split())

ICONOS = [
    (r"diner|precio|pago|pagar|venta|vender|gan[ao]|cobr|factur|\$", "payments"),
    (r"ahorr", "savings"), (r"compra|carrito|tienda", "shopping_cart"),
    (r"negocio|empresa|local|marca", "storefront"), (r"cliente|persona|gente|seguidor|equipo|comunidad", "groups"),
    (r"video|reel|youtube|tiktok|vids", "smart_display"), (r"conten|post|guion|texto|escrib", "edit_note"),
    (r"inteligencia|artificial|^ia$|chatgpt|claude|gemini|autom", "auto_awesome"),
    (r"minuto|hora|tiempo|rápid|segundo", "timer"), (r"día|semana|mes|calendario|fecha", "calendar_month"),
    (r"link|enlace|url|página|web", "link"), (r"coment|mensaje|dm|chat|whatsapp|escríbe", "chat"),
    (r"tutorial|curso|clase|aprend|enseñ|guía|paso", "school"), (r"idea|truco|tip|secreto", "lightbulb"),
    (r"crec|empren|lanz|escal|despeg", "rocket_launch"), (r"avatar|robot|bot|agente", "smart_toy"),
    (r"logo|verific|oficial|calidad", "verified"), (r"fácil|sencill|listo|simple|correct|bien", "check_circle"),
    (r"error|problema|nunca|malo|evita", "cancel"), (r"correo|email|mail", "mail"),
    (r"celular|teléfono|app|móvil", "smartphone"), (r"herramienta|program|software|sistema", "build"),
    (r"dato|número|métrica|resultado|estadíst", "monitoring"), (r"gratis|regalo|bono", "redeem"),
    (r"cabeza|mente|pens|psicolog", "psychology"), (r"viral|fuego|explot", "local_fire_department"),
    (r"mejor|top|estrella|valios|premium", "star"), (r"amor|encant|favorit", "favorite"),
    (r"casa|hogar", "home"), (r"subir|creci|aument|más ventas", "trending_up"), (r"energía|poder|fuerza", "bolt"),
    (r"foto|cámara|grab", "photo_camera"), (r"voz|audio|habl|micr|pódcast|podcast", "mic"),
    (r"trato|socio|alianza|acuerdo", "handshake"), (r"workspace|espacio|oficina", "workspaces"),
    (r"buscar|google|encontr", "search"), (r"idioma|mundo|internacional", "language"),
]

def norm(t):
    return re.sub(r"[^\wáéíóúüñ$]", "", t.lower())

def icono_para(palabra):
    p = norm(palabra)
    for rx, ic in ICONOS:
        if re.search(rx, p):
            return ic
    return "auto_awesome"

def limpio(t):
    return t.strip().strip(",.;:¿?¡!\"'")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("palabras")
    ap.add_argument("--estilo", default="cine-premium")
    ap.add_argument("--gancho")
    ap.add_argument("--cierre")
    ap.add_argument("--cta")
    ap.add_argument("--broll", default="auto")
    ap.add_argument("--sin-broll", action="store_true")
    ap.add_argument("--imagen", action="append", default=[], help="archivo@palabra (aparece cuando dices la palabra)")
    ap.add_argument("--claves", help="palabras clave separadas por coma (si no, se eligen solas)")
    ap.add_argument("--salida")
    a = ap.parse_args()

    ruta_estilo = a.estilo if a.estilo.endswith(".json") else os.path.join(ESTILOS, a.estilo + ".json")
    if not os.path.exists(ruta_estilo) and os.path.exists(os.path.join(PROPIOS, a.estilo + ".json")):
        ruta_estilo = os.path.join(PROPIOS, a.estilo + ".json")
    if not os.path.exists(ruta_estilo):
        disp = ", ".join(sorted(f[:-5] for d in (ESTILOS, PROPIOS) if os.path.isdir(d) for f in os.listdir(d) if f.endswith(".json")))
        sys.exit(f"[kit-editor-ia] No existe el estilo «{a.estilo}». Disponibles: {disp}")
    estilo = json.load(open(ruta_estilo, encoding="utf-8"))
    est = estilo.get("estructura", {})
    datos = json.load(open(a.palabras, encoding="utf-8"))
    W = [w for w in datos["words"] if w["w"].strip()]
    if not W:
        sys.exit("[kit-editor-ia] No hay palabras en la transcripción.")
    dur = datos.get("dur") or (W[-1]["e"] + 0.5)
    evs = []

    # ---- claves candidatas
    elegidas = None
    if a.claves:
        elegidas = [norm(c) for c in a.claves.split(",") if c.strip()]
    def puntaje(i, w):
        p = norm(w["w"])
        if not p or p in VACIAS or len(p) < 4:
            return -1
        s = len(p)
        if w["w"].strip()[:1].isupper() and i > 0:
            s += 4  # nombre propio
        if w["w"].rstrip()[-1:] in ".,!?":
            s += 3  # cierre de frase: suele ser la palabra fuerte
        if icono_para(p) != "auto_awesome":
            s += 4
        elif re.search(r"(ado|ido|ando|iendo|ar|er|ir|aba|ía|amos|emos|imos)$", p):
            s -= 6  # verbos y participios casi nunca son la palabra fuerte
        if elegidas is not None:
            s = 100 if p in elegidas else -1
        return s

    # ---- 1. B-roll inicial
    bd = 0.0
    gancho = a.gancho
    if not gancho:
        cand = sorted([(puntaje(i, w), i) for i, w in enumerate(W) if w["s"] < 6], reverse=True)
        gancho = limpio(W[cand[0][1]]["w"]).upper() if cand and cand[0][0] > 0 else "MIRA ESTO"
    if not a.sin_broll and est.get("broll"):
        bd = min(est["broll"].get("dur", 1.5), max(0.8, dur * 0.08))
        evs.append({"tipo": "broll", "archivo": a.broll if a.broll == "auto" else os.path.abspath(a.broll), "texto": gancho, "t0": 0.0, "t1": round(bd, 2)})
    tr = est.get("transicion", {"tipo": "destello"})
    def transicion(t):
        e = {"tipo": tr.get("tipo", "destello"), "t": round(max(0, t - 0.2), 2), "dur": 0.4 if tr.get("tipo") == "destello" else 0.3}
        if tr.get("color"):
            e["color"] = tr["color"]
            e["fuerza"] = 0.5
        evs.append(e)
    if bd:
        transicion(bd)

    # ---- 2. Texto detrás de apertura
    t_int = (bd, bd + 2.3)
    if est.get("intro") == "titulo":
        evs.append({"tipo": "titulo", "texto": gancho, "t0": round(bd, 2), "t1": round(t_int[1], 2), "detras": True})

    # ---- 4. Cierre (se define antes para no encimar claves)
    cta = a.cta
    cierre = a.cierre
    if not cierre:
        cierre = (cta.split()[-1] if cta else "SÍGUEME").upper()
    t_out = (max(t_int[1] + 2, dur - 3.6), dur)

    # ---- 3. Claves: íconos, acentos, títulos, tarjetas, imágenes
    cada = est.get("cada", 4.0)
    ciclo = est.get("claves", ["icono"])
    colores = estilo.get("colores", ["#38BDF8", "#A78BFA"])
    imagenes = {}
    for im in a.imagen:
        if "@" in im:
            f, p = im.rsplit("@", 1)
            imagenes[norm(p)] = os.path.abspath(f)
    ult = t_int[1] - cada * 0.4
    k = 0
    usadas = set()
    for i, w in enumerate(W):
        p = norm(w["w"])
        if p in imagenes:
            evs.append({"tipo": "imagen", "archivo": imagenes.pop(p), "marco": est.get("marco_imagen", "tarjeta"),
                        "t0": w["s"], "t1": round(w["s"] + 2.4, 2), "x": 0.5, "y": 0.32, "ancho": 0.44, "pantalla": True})
            ult = w["s"]
            continue
        if not (t_int[1] + 0.2 < w["s"] < t_out[0] - 0.6):
            continue
        if w["s"] - ult < cada or puntaje(i, w) < 7 or p in usadas:
            continue
        usadas.add(p)
        tipo = ciclo[k % len(ciclo)]
        k += 1
        txt = limpio(w["w"])
        prev = limpio(W[i - 1]["w"]) if i > 0 else ""
        t0, t1 = w["s"], min(w["s"] + 1.4, t_out[0] - 0.2)
        if tipo == "titulo":
            evs.append({"tipo": "titulo", "texto": txt.upper(), "t0": t0, "t1": round(t1, 2), "detras": True})
        elif tipo == "acento":
            frase = (prev + " " + txt) if prev and norm(prev) in VACIAS and len(prev) <= 3 else txt
            evs.append({"tipo": "acento", "texto": frase.lower() if estilo["id"] == "cine-premium" else frase.upper(), "t0": t0, "t1": round(t1, 2)})
        elif tipo == "icono":
            e = {"tipo": "icono", "icono": icono_para(txt), "t0": t0, "t1": round(t1, 2)}
            if est.get("stickers"):
                lado = 0.26 if k % 2 else 0.74
                e.update({"x": lado, "y": 0.3 if k % 3 else 0.72, "giro": -10 if k % 2 else 10})
            elif estilo["id"] == "cine-premium":
                e.update({"x": 0.5, "y": 0.79})
            else:
                e.update({"x": 0.5, "y": estilo.get("icono", {}).get("y_def", 0.8)})
            evs.append(e)
        elif tipo == "etiqueta":
            evs.append({"tipo": "icono", "icono": icono_para(txt), "etiqueta": txt, "t0": t0, "t1": round(t1 + 0.4, 2), "x": 0.22, "y": 0.13})
        elif tipo == "tarjeta":
            l1 = prev.upper() if prev and len(prev) <= 12 else ""
            evs.append({"tipo": "tarjeta", "icono": icono_para(txt), "l1": l1 or txt.upper(), "l2": txt.upper() if l1 else "",
                        "color": colores[k % len(colores)], "t0": round(max(0, t0 - 0.15), 2), "t1": round(t1 + 0.8, 2)})
        if est.get("zoom", 1) > 1.01:
            evs.append({"tipo": "zoom", "t": t0, "dur": 0.85, "escala": est["zoom"], "modo": est.get("zoom_modo", "golpe")})
        ult = t0
    # zooms de ritmo (estilo energía)
    if est.get("zoom_ritmo"):
        t = t_int[1]
        j = 0
        while t < t_out[0]:
            evs.append({"tipo": "zoom", "t": round(t, 2), "dur": 0.9, "escala": 1.08 if j % 2 else 1.14})
            t += est["zoom_ritmo"]
            j += 1
    # transición a mitad del video, al empezar una frase
    mid = dur / 2
    inicio = next((w["s"] for i, w in enumerate(W) if w["s"] > mid and i > 0 and W[i - 1]["w"].rstrip()[-1:] in ".?!"), None)
    if inicio and t_int[1] < inicio < t_out[0]:
        transicion(inicio)

    # ---- 4. Cierre: texto detrás + CTA
    evs.append({"tipo": "titulo", "texto": cierre, "t0": round(t_out[0], 2), "t1": round(min(dur, t_out[0] + 2.2), 2), "detras": True})
    ctipo = est.get("cta")
    texto_cta = cta or "Sígueme para más"
    if ctipo == "pildora":
        evs.append({"tipo": "cta", "texto": texto_cta, "t0": round(t_out[0] - 0.3, 2), "t1": round(dur + 0.1, 2)})
    elif ctipo == "tarjeta":
        partes = texto_cta.split(" ", 1)
        evs.append({"tipo": "tarjeta", "icono": "chat" if "coment" in texto_cta.lower() else "person_add",
                    "l1": partes[0].upper(), "l2": partes[1].upper() if len(partes) > 1 else "",
                    "color": colores[0], "t0": round(t_out[0] - 0.3, 2), "t1": round(dur + 0.1, 2)})
    elif ctipo == "icono":
        evs.append({"tipo": "icono", "icono": "chat" if "coment" in texto_cta.lower() else "person_add",
                    "etiqueta": texto_cta, "t0": round(t_out[0] + 0.3, 2), "t1": round(dur + 0.1, 2), "x": 0.5, "y": 0.8})

    plan = {k: v for k, v in estilo.items() if k not in ("estructura", "descripcion", "nombre")}
    plan["estilo"] = estilo["id"]
    plan["eventos"] = sorted(evs, key=lambda e: e.get("t0", e.get("t", 0)))
    out = a.salida or os.path.splitext(a.palabras)[0].replace(".palabras", "") + f".plan-{estilo['id']}.json"
    json.dump(plan, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    resumen = {}
    for e in evs:
        resumen[e["tipo"]] = resumen.get(e["tipo"], 0) + 1
    print(f"OK plan {estilo['nombre']} -> {out}")
    print("   " + " · ".join(f"{v} {k}" for k, v in resumen.items()))
    print(f"   gancho detrás: «{gancho}» · cierre detrás: «{cierre}» · CTA: «{texto_cta}»")

if __name__ == "__main__":
    main()
