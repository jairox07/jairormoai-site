"""Quema una o varias capas .ass sobre el video, con las fuentes de marca incluidas en el kit.

Uso: python quemar.py video.mp4 capa1.ass [capa2.ass ...] [--salida final.mp4]
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from ek import KIT, probe, run

ap = argparse.ArgumentParser()
ap.add_argument("video"); ap.add_argument("capas", nargs="+")
ap.add_argument("--salida"); ap.add_argument("--crf", default="18")
a = ap.parse_args()

fonts = os.path.join(os.path.dirname(KIT), "fonts")

def fp(p):  # escapar rutas para el filtro (Windows incluido)
    return os.path.abspath(p).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")

vf = ",".join(f"ass='{fp(c)}':fontsdir='{fp(fonts)}'" for c in a.capas)
out = a.salida or os.path.splitext(a.video)[0] + ".final.mp4"
info = probe(a.video)
cmd = ["ffmpeg", "-y", "-v", "error", "-i", a.video, "-vf", vf,
       "-c:v", "libx264", "-preset", "veryfast", "-crf", a.crf, "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
cmd += ["-c:a", "copy"] if info["audio"] else []
run(cmd + [out])
print(f"OK {out}")
