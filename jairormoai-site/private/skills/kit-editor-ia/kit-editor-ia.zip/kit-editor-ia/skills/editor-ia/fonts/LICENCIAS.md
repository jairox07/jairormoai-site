# Tipografías e íconos incluidos (uso libre, también comercial)
- Anton, Inter, Montserrat, Poppins, Playfair Display, Exo 2 — SIL Open Font License 1.1 (Google Fonts)
- Luckiest Guy — Apache License 2.0 (Google Fonts)
- Material Symbols Rounded — Apache License 2.0 (Google)
Se pueden usar en videos comerciales. No se venden por separado.
