# © 2026 Jairo Romo · jairoromo.ai · Kit Editor IA — licencia de uso personal, ver LICENCIA.txt. Prohibido compartir o revender.
"""Crea tu ESTILO DE MARCA: las mismas animaciones del kit (títulos, acentos, pasos, destellos, flashes, zooms,
sonidos) pero con tus colores y tus tipografías.

Uso:
  python marca.py --nombre acme --colores "#0A2540,#FF8A00" [--color3 "#FFFFFF"]
        [--base cine-premium|explicador|negocios-bold|neon-marca|notificacion|podcast-minimal|reto-energia]
        [--fuente-titulo Anton-Regular.ttf | ruta/a/tu.ttf] [--fuente-texto Inter[opsz,wght].ttf | ruta/a/tu.ttf]
        [--titulo color|metal] [--descripcion "..."]

Guarda ~/.kit-editor-ia/estilos/mio-<nombre>.json con "base": el estilo hereda de fábrica toda la composición
de la base y solo cambia lo de tu marca. Para editar: «edítalo con mi estilo mio-<nombre>».
"""
import argparse, json, os, re, shutil, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
ESTILOS = os.path.join(os.path.dirname(AQUI), "estilos")
FUENTES = os.path.join(os.path.dirname(AQUI), "fonts")
HOME = os.path.join(os.path.expanduser("~"), ".kit-editor-ia")

def hexa(c):
    c = c.strip().lstrip("#")
    if len(c) == 3:
        c = "".join(x * 2 for x in c)
    if not re.fullmatch(r"[0-9a-fA-F]{6}", c):
        sys.exit(f"[kit-editor-ia] Color inválido: «{c}». Usa formato #RRGGBB.")
    return "#" + c.upper()

def lum(c):
    r, g, b = (int(c[i:i + 2], 16) / 255 for i in (1, 3, 5))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b

def mezcla(c, hacia, k):
    a = [int(c[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(hacia[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * k):02X}" for x, y in zip(a, b))

def tinta(c):  # texto legible sobre un color
    return "#111111" if lum(c) > 0.55 else "#FFFFFF"

def fuente(valor, carpeta_usuario):
    """Nombre de una fuente del kit o ruta a un .ttf/.otf del usuario (se copia a ~/.kit-editor-ia/fuentes)."""
    if not valor:
        return None
    if os.path.exists(os.path.join(FUENTES, valor)):
        return valor
    if os.path.isfile(valor) and valor.lower().endswith((".ttf", ".otf")):
        os.makedirs(carpeta_usuario, exist_ok=True)
        dest = os.path.join(carpeta_usuario, os.path.basename(valor))
        shutil.copy(valor, dest)
        return dest
    sys.exit(f"[kit-editor-ia] No encuentro la tipografía «{valor}». Usa una del kit (carpeta fonts) o la ruta a tu .ttf.")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nombre", required=True)
    ap.add_argument("--colores", required=True, help="principal,secundario (ej. #0A2540,#FF8A00)")
    ap.add_argument("--color3")
    ap.add_argument("--base", default="cine-premium")
    ap.add_argument("--fuente-titulo"); ap.add_argument("--fuente-texto")
    ap.add_argument("--titulo", choices=["color", "metal"], default="color")
    ap.add_argument("--descripcion")
    a = ap.parse_args()

    cols = [hexa(c) for c in a.colores.split(",") if c.strip()]
    if not cols:
        sys.exit("[kit-editor-ia] Dame al menos un color de tu marca.")
    p = cols[0]
    s = cols[1] if len(cols) > 1 else mezcla(p, "#FFFFFF", 0.55)
    t = hexa(a.color3) if a.color3 else ("#FFFFFF" if lum(p) < 0.7 else "#111111")
    # el color con el que se leen títulos y acentos sobre video: el más claro de los dos de marca, o el principal si es vivo
    vivo = p if 0.25 < lum(p) < 0.9 else s
    nombre = re.sub(r"[^a-z0-9-]", "", a.nombre.lower().replace(" ", "-")) or "marca"
    ruta_base = os.path.join(ESTILOS, a.base + ".json")
    if not os.path.exists(ruta_base):
        sys.exit(f"[kit-editor-ia] La base «{a.base}» no existe. Opciones: " + ", ".join(sorted(f[:-5] for f in os.listdir(ESTILOS) if f.endswith('.json'))))
    base = json.load(open(ruta_base, encoding="utf-8"))
    fu_t = fuente(a.fuente_titulo, os.path.join(HOME, "fuentes"))
    fu_x = fuente(a.fuente_texto, os.path.join(HOME, "fuentes"))

    est = {
        "base": a.base,
        "id": f"mio-{nombre}",
        "nombre": f"Mi marca · {a.nombre}",
        "descripcion": a.descripcion or f"Las animaciones de {base['nombre']} con los colores y la tipografía de tu marca.",
        "colores": [p, s],
        "portada": {"color1": mezcla(p, "#000000", 0.82), "color2": mezcla(p, "#000000", 0.45)},
        "estructura": {"flash_color": vivo, "destello_color": vivo, "transicion": dict(base["estructura"].get("transicion", {}), **({"color": vivo} if base["estructura"].get("transicion", {}).get("tipo") != "destello" else {}))},
    }
    # --- titulares gigantes
    ti = {}
    if a.titulo == "color" or base.get("titulo", {}).get("estilo") != "metal":
        ti.update({"estilo": "color", "color": vivo})
    if fu_t:
        ti["fuente"] = fu_t; ti["var"] = None
    if ti:
        est["titulo"] = ti
    # --- subtítulos: palabra activa/clave con el color de marca
    su = {}
    if base.get("subtitulos", {}).get("activo_color") or "activo_color" in base.get("subtitulos", {}):
        su["activo_color"] = vivo
    if "clave_color" in base.get("subtitulos", {}):
        su["clave_color"] = s if s != vivo else vivo
    if fu_x:
        su["fuente"] = fu_x; su["var"] = None
    if su:
        est["subtitulos"] = su
    # --- acentos, pasos, píldora, íconos, tarjetas
    est["acento"] = {"color": t if lum(t) > 0.5 else vivo, **({"fuente": fu_t} if fu_t else {})}
    est["pasos"] = {"punto": vivo, **({"fuente": fu_x} if fu_x else {})}
    est["pildora"] = {"color": s, **({"fuente": fu_x} if fu_x else {})}
    est["icono"] = {"color": vivo, "icono_color": tinta(vivo)}
    est["tarjeta"] = {**({"fuente": fu_x} if fu_x else {})}
    if not est["tarjeta"]:
        est.pop("tarjeta")

    dest_dir = os.path.join(HOME, "estilos")
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, f"mio-{nombre}.json")
    json.dump(est, open(dest, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"OK estilo de marca -> {dest}")
    print(f"   base: {a.base} · colores: {p} / {s} · acento de luz y flash: {vivo}")
    print(f"   Úsalo con: plan.py --estilo mio-{nombre}")

if __name__ == "__main__":
    main()
