# © 2026 Jairo Romo · jairoromo.ai · Kit Editor IA — licencia de uso personal, ver LICENCIA.txt. Prohibido compartir o revender.
"""Palabra de cromo 3D real (Three.js en un Chromium sin ventana) -> PNG transparente.

Lo usa motor.py para los títulos de estilo «metal». Si no hay playwright/Chromium, motor.py usa el
cromo plano de siempre, así que el kit funciona igual. Se instala con el instalador del kit
(pip install playwright + playwright install chromium).

Uso suelto: python cromo.py "TEXTO" salida.png [--fuente Anton-Regular.ttf]
"""
import argparse, hashlib, http.server, os, shutil, socketserver, sys, tempfile, threading

AQUI = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(AQUI)
VENDOR = os.path.join(SKILL, "vendor", "cromo")
CACHE = os.path.join(os.path.expanduser("~"), ".kit-editor-ia", "cache", "cromo")


def disponible():
    if os.environ.get("KIT_SIN_CROMO"):
        return False
    try:
        import playwright.sync_api  # noqa: F401
    except Exception:
        return False
    return os.path.isdir(VENDOR)


def renderizar(texto, fuente_ttf, estira=1.32):
    """Devuelve la ruta de un PNG RGBA recortado al texto (cacheado), o None si falla."""
    os.makedirs(CACHE, exist_ok=True)
    clave = hashlib.sha1(f"v1|{texto}|{os.path.basename(fuente_ttf)}|{estira}".encode()).hexdigest()[:16]
    out = os.path.join(CACHE, clave + ".png")
    if os.path.exists(out):
        return out
    if not disponible():
        return None
    tmp = tempfile.mkdtemp(prefix="cromo_")
    try:
        os.symlink(os.path.join(VENDOR, "three"), os.path.join(tmp, "three"))
    except OSError:
        shutil.copytree(os.path.join(VENDOR, "three"), os.path.join(tmp, "three"))
    shutil.copy(os.path.join(VENDOR, "cromo.html"), tmp)
    shutil.copy(fuente_ttf, os.path.join(tmp, "fuente.ttf"))

    class H(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=tmp, **k)
        def log_message(self, *a):
            pass
    srv = socketserver.TCPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        from playwright.sync_api import sync_playwright
        from urllib.parse import quote
        from PIL import Image
        import io
        with sync_playwright() as p:
            b = p.chromium.launch(args=["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
            pg = b.new_page(viewport={"width": 2048, "height": 1024})
            pg.goto(f"http://127.0.0.1:{srv.server_address[1]}/cromo.html?t={quote(texto)}&f=fuente.ttf&e={estira}")
            pg.wait_for_function("window.__done===true", timeout=60000)
            err = pg.evaluate("window.__error||''")
            if err:
                raise RuntimeError(err)
            png = pg.locator("#c").screenshot(omit_background=True)
            b.close()
        im = Image.open(io.BytesIO(png)).convert("RGBA")
        bb = im.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox()
        if not bb:
            return None
        im.crop(bb).save(out)
        return out
    except Exception as e:
        print(f"[kit-editor-ia] cromo 3D no disponible ({str(e)[:120]}); uso el cromo plano.", file=sys.stderr)
        return None
    finally:
        srv.shutdown()
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("texto"); ap.add_argument("salida")
    ap.add_argument("--fuente", default=os.path.join(SKILL, "fonts", "Anton-Regular.ttf"))
    a = ap.parse_args()
    r = renderizar(a.texto, a.fuente)
    if not r:
        sys.exit("No pude renderizar el cromo 3D (falta playwright o Chromium).")
    shutil.copy(r, a.salida)
    print("OK", a.salida)
