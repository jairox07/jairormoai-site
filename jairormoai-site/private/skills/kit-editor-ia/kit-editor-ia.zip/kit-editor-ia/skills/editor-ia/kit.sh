#!/usr/bin/env bash
# Kit Editor IA · lanzador único. Uso: bash ~/.kit-editor-ia/kit <comando> [args]
# Comandos: revisar transcribir planear_cortes aplicar_cortes textos quemar fondo musica analizar
KIT="$HOME/.claude/skills/editor-ia/scripts"
PY="$HOME/.kit-editor-ia/venv/bin/python"
[ -x "$PY" ] || PY="$HOME/.kit-editor-ia/venv/Scripts/python.exe"
if [ ! -e "$PY" ]; then
  echo "[kit-editor-ia] No encuentro el entorno de Python del kit. Corre el instalador otra vez (INSTALAR.md)."
  exit 1
fi
# Windows: ffmpeg recién instalado con winget puede no estar en el PATH de esta terminal todavía
if ! command -v ffmpeg >/dev/null 2>&1 && [ -n "$LOCALAPPDATA" ] && command -v cygpath >/dev/null 2>&1; then
  L="$(cygpath -u "$LOCALAPPDATA")"
  export PATH="$PATH:$L/Microsoft/WinGet/Links"
  for d in "$L"/Microsoft/WinGet/Packages/Gyan.FFmpeg*/ffmpeg-*/bin; do [ -d "$d" ] && export PATH="$PATH:$d"; done
fi
cmd="$1"; shift || true
if [ -z "$cmd" ] || [ ! -f "$KIT/$cmd.py" ]; then
  echo "Comandos: revisar transcribir planear_cortes aplicar_cortes textos quemar fondo musica analizar"
  exit 1
fi
export PYTHONUTF8=1 PYTHONIOENCODING=utf-8
exec "$PY" "$KIT/$cmd.py" "$@"
