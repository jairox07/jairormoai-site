"""Aplica un plan de cortes y re-mapea los tiempos de las palabras al video nuevo.

Uso: python aplicar_cortes.py video.mp4 plan.json [--palabras palabras.json] [--salida editado.mp4]
Genera editado.mp4 y, si das --palabras, editado.palabras.json con tiempos ya corregidos
(listo para subtítulos, gancho o checklist).
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from ek import load, probe, run, save

ap = argparse.ArgumentParser()
ap.add_argument("video"); ap.add_argument("plan")
ap.add_argument("--palabras"); ap.add_argument("--salida")
ap.add_argument("--crf", default="18")
a = ap.parse_args()

keep = load(a.plan)["keep"]
info = probe(a.video)
out = a.salida or os.path.splitext(a.video)[0] + ".editado.mp4"

parts, labels = [], []
for i, (s, e) in enumerate(keep):
    parts.append(f"[0:v]trim=start={s}:end={e},setpts=PTS-STARTPTS[v{i}]")
    if info["audio"]:
        parts.append(f"[0:a]atrim=start={s}:end={e},asetpts=PTS-STARTPTS,"
                     f"afade=t=in:d=0.015,afade=t=out:st={max(0,e-s-0.015):.3f}:d=0.015[a{i}]")
        labels.append(f"[v{i}][a{i}]")
    else:
        labels.append(f"[v{i}]")
n = len(keep)
parts.append("".join(labels) + f"concat=n={n}:v=1:a={1 if info['audio'] else 0}[v]" + ("[a]" if info["audio"] else ""))
fc = ";".join(parts)
cmd = ["ffmpeg", "-y", "-v", "error", "-i", a.video, "-filter_complex", fc, "-map", "[v]"]
if info["audio"]:
    cmd += ["-map", "[a]", "-c:a", "aac", "-b:a", "192k"]
cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", a.crf, "-pix_fmt", "yuv420p", "-movflags", "+faststart", out]
run(cmd)

if a.palabras:
    words = load(a.palabras)["words"]
    nuevas, offset = [], 0.0
    for s, e in keep:
        for w in words:
            if w["s"] >= s - 0.01 and w["e"] <= e + 0.01:
                nuevas.append({"w": w["w"], "s": round(w["s"] - s + offset, 3), "e": round(w["e"] - s + offset, 3)})
        offset += e - s
    pw = os.path.splitext(out)[0] + ".palabras.json"
    save({"words": nuevas, "dur": round(offset, 3), "video": os.path.abspath(out)}, pw)
    print(f"palabras re-mapeadas -> {pw}")
print(f"OK {out} ({probe(out)['dur']:.1f}s)")
