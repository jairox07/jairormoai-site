# © 2026 Jairo Romo · jairoromo.ai · Kit Editor IA — licencia de uso personal, ver LICENCIA.txt. Prohibido compartir o revender.
"""Vista previa rápida de un plan: renderiza solo unos instantes clave y arma una hoja de cuadros
para que el usuario apruebe el estilo antes del render completo (que puede tardar varios minutos).

Uso: python muestra.py video.editado.mp4 video.editado.palabras.json plan.json [--salida muestra.jpg]
Toma: el B-roll, el texto detrás de apertura, 3 elementos clave y el cierre.
"""
import argparse, json, os, subprocess, sys, tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser()
ap.add_argument("video"); ap.add_argument("palabras"); ap.add_argument("plan")
ap.add_argument("--salida")
a = ap.parse_args()

plan = json.load(open(a.plan, encoding="utf-8"))
evs = plan.get("eventos", [])
momentos = []
for e in evs:
    t0 = e.get("t0", e.get("t"))
    if t0 is None:
        continue
    if e["tipo"] == "broll":
        momentos.append(("B-roll", (e["t0"] + e["t1"]) / 2))
    elif e["tipo"] == "titulo":
        momentos.append(("Texto detrás", t0 + 0.7))
    elif e["tipo"] in ("icono", "acento", "tarjeta", "imagen", "pasos"):
        momentos.append((e["tipo"].capitalize(), t0 + 0.6))
    elif e["tipo"] == "cta":
        momentos.append(("Cierre", t0 + 1.0))
# elegir hasta 6, repartidos
vistos, sel = set(), []
for etq, t in momentos:
    if etq in ("Icono", "Acento", "Tarjeta", "Imagen", "Pasos") and sum(1 for s in sel if s[0] in ("Icono", "Acento", "Tarjeta", "Imagen", "Pasos")) >= 3:
        continue
    if etq == "Texto detrás" and sum(1 for s in sel if s[0] == etq) >= 2:
        continue
    sel.append((etq, t))
sel = sorted(sel, key=lambda x: x[1])[:6]
tmp = tempfile.mkdtemp()
cuadros = []
for i, (etq, t) in enumerate(sel):
    out = os.path.join(tmp, f"m{i}.mp4")
    subprocess.run([sys.executable, os.path.join(AQUI, "motor.py"), a.video, a.palabras, a.plan, "--salida", out,
                    "--desde", f"{max(0, t - 0.05):.2f}", "--hasta", f"{t + 0.1:.2f}"], check=True, capture_output=True)
    png = os.path.join(tmp, f"m{i}.png")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", out, "-frames:v", "1", "-vf", "scale=360:-2", png], check=True)
    cuadros.append(png)
    print(f"  ✓ {etq} ({t:.1f}s)")
salida = a.salida or os.path.splitext(a.plan)[0] + ".muestra.jpg"
ins = []
for c in cuadros:
    ins += ["-i", c]
subprocess.run(["ffmpeg", "-v", "error", "-y", *ins, "-filter_complex",
                f"hstack=inputs={len(cuadros)}" if len(cuadros) > 1 else "null", salida], check=True)
print(f"OK {salida} — ábrela y enséñasela al usuario antes del render completo")
