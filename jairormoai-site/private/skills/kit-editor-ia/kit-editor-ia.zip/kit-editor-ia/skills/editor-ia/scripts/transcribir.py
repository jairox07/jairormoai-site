"""Transcribe un video con tiempos por palabra.

Uso: python transcribir.py video.mp4 [--salida palabras.json] [--modelo small] [--idioma es]
Salida: {"words": [{"w": "hola", "s": 0.12, "e": 0.40}, ...], "dur": 21.3}
Todo corre en tu computadora (faster-whisper). La primera vez descarga el modelo.
"""
import argparse, os, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from ek import probe, run, save

ap = argparse.ArgumentParser()
ap.add_argument("video")
ap.add_argument("--salida")
ap.add_argument("--modelo", default="small", help="tiny | base | small | medium | large-v3")
ap.add_argument("--idioma", default="es")
ap.add_argument("--gpu", action="store_true", help="usar tarjeta NVIDIA con CUDA instalado")
a = ap.parse_args()

try:
    from faster_whisper import WhisperModel
except ImportError:
    sys.exit("[kit-editor-ia] Falta faster-whisper: pip install faster-whisper")

info = probe(a.video)
wav = os.path.join(tempfile.mkdtemp(), "audio.wav")
run(["ffmpeg", "-y", "-v", "error", "-i", a.video, "-vn", "-ac", "1", "-ar", "16000", wav])

try:
    model = WhisperModel(a.modelo, device="cuda" if a.gpu else "cpu", compute_type="float16" if a.gpu else "int8")
except Exception as e:
    sys.exit("[kit-editor-ia] No pude cargar el modelo de voz. La primera vez se descarga (~500 MB): "
             "revisa tu internet y vuelve a intentar. Si usas --gpu, quítalo.\nDetalle: " + str(e)[:300])
segs, _ = model.transcribe(wav, language=a.idioma, word_timestamps=True, vad_filter=False,
                           condition_on_previous_text=False)
words = []
for seg in segs:
    for w in seg.words or []:
        t = w.word.strip()
        if t:
            words.append({"w": t, "s": round(w.start, 3), "e": round(w.end, 3)})

out = a.salida or os.path.splitext(a.video)[0] + ".palabras.json"
save({"words": words, "dur": info["dur"], "video": os.path.abspath(a.video)}, out)
print(f"OK {len(words)} palabras -> {out}")
print(" ".join(w["w"] for w in words))
