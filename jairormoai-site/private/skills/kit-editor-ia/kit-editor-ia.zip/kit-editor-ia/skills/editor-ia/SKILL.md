---
name: editor-ia
description: Editor de video del Kit Editor IA v2 (jairoromo.ai). Úsalo cuando el usuario mande un video hablado (Reels, TikTok, anuncio, clase) y pida editarlo, aplicarle un estilo (Cine Premium, Notificación, Negocios Bold, Podcast Minimal, Reto / Energía, Explicador, Neón de marca o uno propio), cortarlo, quitar pausas o errores, quedarse con la mejor toma, poner subtítulos, gancho, checklist, cambiar el fondo, poner una palabra detrás, música o efectos, o copiar el estilo de otro Reels. También para instalar o revisar el kit.
---

# Kit Editor IA · jairoromo.ai

Tú eres el editor. El usuario graba como le salga, te manda el video y te dice en español lo que quiere. Tú lo editas en SU computadora con los scripts de este kit y le devuelves el archivo final. Nada se publica: tú editas, él publica.

**Cómo se corre todo:** cada herramienta se llama con el lanzador del kit, `bash ~/.kit-editor-ia/kit <comando> [argumentos]`. El lanzador usa el Python propio del kit (en `~/.kit-editor-ia/venv`) y funciona igual en Mac y en Windows (Git Bash). No llames a `python` o `python3` directamente. Pon siempre las rutas de video entre comillas, porque en Windows suelen tener espacios ("C:/Users/Jairo Romo/…").

## 0. Antes de editar (solo la primera vez)
Corre `bash ~/.kit-editor-ia/kit revisar`.
- Si dice que no encuentra el entorno, el kit no se instaló: busca la carpeta descomprimida `kit-editor-ia` (Descargas o Escritorio) y corre su instalador. En Windows: `powershell -ExecutionPolicy Bypass -File "<carpeta>/instalar.ps1"`. En Mac: `bash "<carpeta>/instalar.sh"`.
- Si solo falta ffmpeg en Windows justo después de instalar: pide al usuario cerrar y abrir Claude Code una vez.
- En Mac sin Homebrew, el usuario debe correr en la app Terminal el comando que muestra el instalador, porque pide su contraseña. Explícaselo en una línea.

Avisa en la primera edición: la transcripción descarga el modelo de voz (~500 MB) y el primer cambio de fondo baja el modelo de recorte (~170 MB). Solo pasa una vez.

## 0.5 Modo híbrido (cuánto preguntar)
- Si el pedido es claro ("quita pausas y pon subtítulos"), **no preguntes**: edita.
- Si es vago ("edítame esto", "no sé qué pedir"), usa el asistente `/editar` (catálogo con imágenes, estilo propio, B-roll, gancho y cierre) y luego edita. Si el usuario dice "tú decide", decide tú y sigue.
- Si pide un estilo por nombre o "como el anterior", ve directo al flujo de **Estilos v2** (sección 4).
- El usuario puede pedir `/editar` en cualquier momento si quiere que lo guíes paso a paso.

## 1. Flujo estándar ("edítame este video")
Trabaja siempre sobre una copia en la carpeta del video. Nunca sobrescribas el original.

1. **Transcribe** → `bash ~/.kit-editor-ia/kit transcribir video.mp4`
   Lee la transcripción completa antes de decidir nada.
2. **Planea los cortes** → `bash ~/.kit-editor-ia/kit planear_cortes video.palabras.json`
   Revisa `frases` y `quitadas` del plan. Si algo no tiene sentido (se cortó una idea a la mitad, o quedó una toma repetida), edita `keep` a mano.
3. **Aplica** → `bash ~/.kit-editor-ia/kit aplicar_cortes video.mp4 video.plan.json --palabras video.palabras.json`
   Esto genera `video.editado.mp4` y `video.editado.palabras.json`, con los tiempos ya corregidos.
4. **Capas de texto** (sobre `video.editado.palabras.json`): subtítulos, gancho y checklist con `textos.py`.
5. **Quema** → `bash ~/.kit-editor-ia/kit quemar video.editado.mp4 capa1.ass capa2.ass`
6. **Música y efectos** (opcional) → `musica.py` · **sonidos sutiles** (solo si los piden) → `sonidos.py`
7. **Revisa antes de entregar** → `bash ~/.kit-editor-ia/kit analizar prueba video.final.mp4`. Abre la hoja de cuadros y confirma que los textos no se salen ni tapan la cara, y que no quedaron cortes bruscos.
8. **Entrega**: di la duración antes → después, qué quitaste (pausas, tomas, errores) y dónde quedó el archivo. Ofrece un ajuste concreto: "¿Quieres el gancho más grande?" o "¿Probamos otra versión con otro gancho?".

## 2. Qué pedido activa qué herramienta
| El usuario dice… | Herramienta | Comando clave |
|---|---|---|
| "edítalo con estilo X", "que se vea profesional" | Estilos v2 | `plan` → `muestra` → `motor` (sección 4) |
| "¿qué estilos hay?" | /estilos | abre `estilos/catalogo.jpg` |
| "quiero mi propio estilo", un link | /referencia | `descargar` + `analizar referencia` → estilo propio |
| "quita las pausas", "córtalo" | /corte | `planear_cortes.py --pausa 0.45` (más agresivo: 0.3) |
| "quédate con la última/mejor toma" | /toma | `planear_cortes.py` (las tomas se detectan solas) + revisión manual |
| "quita la parte donde digo X" | /corte | `planear_cortes.py --quitar "X"` |
| "subtítulos palabra por palabra" | /subtitulos | `textos.py subtitulos … --estilo karaoke` |
| "gancho fuerte al inicio" | /gancho | `textos.py gancho … --texto "…"` |
| "haz un checklist de lo que diga" | /checklist | `textos.py checklist … --item … --item …` |
| "cambia el fondo", "sin pantalla verde" | /fondo | `fondo.py … --fondo imagen.jpg` |
| "pon la frase detrás de mí" | /impacto | `textos.py impacto` + `fondo.py --detras` |
| "ponle sonidos", "sonidos sutiles" | /sonidos | `sonidos.py video.final.mp4 plan.json` |
| "ponle música", "efecto de sonido" | /musica | `musica.py --musica … --sfx archivo@seg` |
| "edítalo como este Reels" | /referencia | `analizar.py referencia ref.mp4` |
| "¿cómo quedó?" | /prueba | `analizar.py prueba` |

## 3. Criterio de editor (lo que te hace bueno)
- **Ganchos**: los primeros 2 segundos deciden todo. Si el usuario no da gancho, propón 3 opciones de máximo 6 palabras, sacadas de lo que dijo, y usa la más fuerte.
- **Ritmo**: en Reels hablados, ninguna pausa de más de 0.4 s. En clases o tutoriales, 0.6 s.
- **Subtítulos**: de 2 a 4 palabras por bloque, en el tercio inferior, sin tapar la boca. Para anuncios, `--estilo caja`.
- **Anuncios**: avisa si una frase puede ser rechazada por Meta o TikTok, por ejemplo promesas de dinero, antes/después de salud o "tú" señalando atributos personales.
- **Varias versiones**: si piden "versiones", entrega el mismo corte con 3 ganchos distintos (`video.v1/v2/v3.mp4`).
- Formato ideal: video hablado, vertical, de 20 a 90 s. Si te mandan horizontal, pregunta si lo recortas a 9:16 (`ffmpeg -vf crop=ih*9/16:ih`).

## 4. Estilos v2 (plantillas con diseño completo)
Cada estilo trae **la misma estructura** y su propio diseño (tipografías, subtítulos, colores, elementos):
1. **B-roll inicial** (clip o foto del usuario; si no hay, portada animada con el gancho) y transición.
2. **Texto gigante DETRÁS de la persona al abrir** (el gancho, 1 o 2 palabras).
3. **Íconos, imágenes, acentos o tarjetas en las palabras clave**, con zooms y transiciones.
4. **Texto gigante DETRÁS al cerrar** + llamado a la acción (píldora, tarjeta o ícono).

Catálogo: `estilos/catalogo.jpg` (muestras en `estilos/muestras/`). Plantillas: `estilos/*.json`. Estilos propios del usuario: `~/.kit-editor-ia/estilos/*.json` (los crea `/referencia`).

| id | Estilo | Para |
|---|---|---|
| cine-premium | Cine Premium | anuncios, lanzamientos, marca premium |
| notificacion | Notificación | tutoriales, tips, tecnología |
| negocios-bold | Negocios Bold | opinión, negocios, consejos directos |
| podcast-minimal | Podcast Minimal | entrevistas, pódcast, reflexiones |
| reto-energia | Reto / Energía | retos, entretenimiento, dinámicas |
| explicador | Explicador | clases, explicaciones paso a paso |
| neon-marca | Neón de marca | marca personal colorida |

### Flujo con estilo
1. Transcribe y corta como en la sección 1 (pasos 1–3) → `video.editado.mp4` + `video.editado.palabras.json`.
2. **Plan automático (borrador):**
   `bash ~/.kit-editor-ia/kit plan video.editado.palabras.json --estilo cine-premium --gancho "OUTRO" --cierre "TUTORIAL" --cta "Comenta TUTORIAL" --broll "clip.mp4" --imagen "captura.png@app"`
   (sin `--broll` usa portada animada; `--sin-broll` lo quita; `--claves "a,b,c"` fija las palabras clave).
3. **Revisa y mejora el plan (esto es lo que te hace buen editor):** abre `video.editado.plan-<estilo>.json` y corrige:
   - Claves: deben ser las palabras con más peso (sustantivos, cifras, nombres, beneficios), no verbos sueltos. 1 cada 3–5 s.
   - Íconos: que el ícono signifique lo que dice (nombres en `fonts/MaterialSymbolsRounded.codepoints`, p. ej. payments, timer, school, rocket_launch, smart_toy, chat, link, storefront, groups, check_circle, cancel, lightbulb, auto_awesome).
   - Texto detrás: 1 palabra de máximo ~10 letras (o 2 cortas). Al abrir el gancho y al cerrar la acción.
   - Si el usuario enumera pasos ("primero…, luego…"), agrega una escena `pasos` (vidrio con los pasos que entran al decirlos).
   - Que nada tape la cara: títulos en `y` 0.22–0.30 (la cabeza los tapa por abajo, eso es lo bonito), subtítulos 0.60–0.70.
4. **Muestra antes del render completo:** `bash ~/.kit-editor-ia/kit muestra video.editado.mp4 video.editado.palabras.json plan.json` → abre la hoja y enséñasela. Ajusta si pide cambios.
5. **Render:** `bash ~/.kit-editor-ia/kit motor video.editado.mp4 video.editado.palabras.json plan.json --salida video.final.mp4`
   - Tarda: ~1–2 min por cada 10 s de video. El texto detrás recorta la silueta cuadro por cuadro (la primera vez baja el modelo de recorte, ~170 MB).
6. Música: al final, con `musica.py` sobre `video.final.mp4`.
   - **Sonidos sutiles (solo si la persona los pidió; apagados por defecto):** `bash ~/.kit-editor-ia/kit sonidos video.final.mp4 plan.json [--nivel 0.5|1|1.5] [--musica pista.mp3]`. Pone un pop, whoosh, impacto, brillo o tick en cada elemento del plan, ~12–15 dB bajo la voz.
7. Revisa con `analizar prueba` y entrega.

### Eventos del plan (para ajustar a mano)
- `broll` {archivo: clip.mp4 | foto.jpg | "auto", texto, t0, t1}
- `titulo` {texto, t0, t1, detras: true/false, y, tam, estilo: metal | blanco | color, color, fuente, var}
  - `estilo: metal` usa cromo 3D real (Three.js en un Chromium sin ventana, `scripts/cromo.py`, PNG en caché en `~/.kit-editor-ia/cache/cromo`). Si falta playwright/Chromium cae solo al cromo plano; `cromo: false` en el evento o `KIT_SIN_CROMO=1` lo desactivan.
- `acento` {texto, t0, t1, y, tam, color, fuente} → frase en cursiva o la fuente del estilo
- `icono` {icono, t0, t1, x, y, radio, color, fondo: circulo | nada, giro, etiqueta}
- `imagen` {archivo, t0, t1, x, y, ancho, marco: tarjeta | celular | nada}
- `tarjeta` {icono, l1, l2, color, acento_linea: 1|2, t0, t1} → notificación de vidrio arriba
- `pasos` {t0, t1, titulo, items: [{texto, t}]} → escena de vidrio con pasos
- `cta` {texto, t0, t1, y} → píldora de vidrio
- `zoom` {t, dur, escala, modo: golpe | empuje} · `destello` {t, dur} · `flash` {t, dur, color, fuerza}
- `subtitulos` (en la raíz del plan): modo frase | palabra | ninguno, fuente, var, tam, y, mayusculas, max_palabras, tenue, activo_color, claves, clave_color, clave_fuente, clave_brillo, contorno, contorno_color, caja, pop.

### Links y videos de referencia
- `bash ~/.kit-editor-ia/kit descargar "<link>"` baja un Reel, TikTok o Short **solo para estudiar su estilo** (skill `/referencia`). Si el link pide sesión, pide una grabación de pantalla.

## 5. Privacidad
El video nunca sale de la computadora. Solo lees el texto transcrito y algunos cuadros para decidir.

## 6. Si algo falla
- Error de ffmpeg con rutas en Windows: mueve el video a una carpeta sin espacios ni acentos.
- `fondo.py` muy lento: usa `--fps 15` para la prueba y el fps completo para la versión final.
- El corte se come palabras: baja `--margen` o sube `--pausa`.
- Fuentes: el kit incluye Exo 2, Anton, Inter, Montserrat, Poppins, Playfair Display, Luckiest Guy y los íconos Material Symbols en `fonts/` (licencias libres OFL / Apache 2.0).
- El motor de estilos va lento: prueba primero con `muestra`; para el render final deja la compu trabajando.

¿Dudas o algo a la medida? Agenda una sesión con Jairo: https://jairoromoai.novotech.mx/sessions
