# © 2026 Jairo Romo · jairoromo.ai · Kit Editor IA — licencia de uso personal, ver LICENCIA.txt. Prohibido compartir o revender.
"""Sonidos sutiles para el video (OPCIONAL: solo se usan cuando la persona los pide).

Genera efectos sintéticos sin derechos (ffmpeg), los pone justo cuando ocurre cada elemento del plan
(títulos, acentos, íconos, imágenes, destellos, B-roll, llamado a la acción) y los mezcla con tu voz.
Quedan ~12-15 dB por debajo de la voz: se sienten, no se notan.

Uso:
  python sonidos.py video.mp4 plan.json [--salida video.sonido.mp4] [--nivel 1.0] [--musica pista.mp3]
  --nivel  0.5 = casi imperceptibles · 1.0 = sutiles (por defecto) · 1.5 = más presentes
"""
import argparse, os, subprocess, sys, tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(os.path.expanduser("~"), ".kit-editor-ia", "cache", "sfx")

# nombre -> (filtro de síntesis, pico objetivo en dBFS)
SONIDOS = {
    "pop": ("aevalsrc='sin(2*PI*(640+420*t/0.12)*t)*exp(-t*38)*0.9':d=0.16:s=44100", "lowpass=f=3200", -22),
    "whoosh": ("anoisesrc=d=0.5:c=pink:a=0.7:r=44100", "bandpass=f=1800:width_type=h:w=2600,afade=t=in:st=0:d=0.22,afade=t=out:st=0.22:d=0.28", -23),
    "impacto": ("aevalsrc='sin(2*PI*(58+30*exp(-t*18))*t)*exp(-t*7)*0.9':d=0.7:s=44100", "lowpass=f=240,aecho=0.7:0.5:90:0.25", -17),
    "brillo": ("aevalsrc='(sin(2*PI*2349*t)+0.5*sin(2*PI*3520*t))*exp(-t*9)*0.4':d=0.5:s=44100", "highpass=f=1200,aecho=0.6:0.4:60:0.3", -24),
    "tick": ("aevalsrc='sin(2*PI*1500*t)*exp(-t*70)*0.8+if(gt(t,0.11),sin(2*PI*2000*(t-0.11))*exp(-(t-0.11)*70)*0.8,0)':d=0.3:s=44100", "lowpass=f=5000", -25),
}

def ff(*args):
    r = subprocess.run(["ffmpeg", "-v", "error", "-y", *args], capture_output=True, text=True)
    if r.returncode:
        sys.exit("[kit-editor-ia] ffmpeg: " + r.stderr[-400:])

def generar():
    os.makedirs(CACHE, exist_ok=True)
    rutas = {}
    for nombre, (src, filtro, pico) in SONIDOS.items():
        out = os.path.join(CACHE, f"{nombre}.wav")
        if not os.path.exists(out):
            crudo = os.path.join(CACHE, f"_{nombre}.wav")
            ff("-f", "lavfi", "-i", src, "-af", filtro, crudo)
            r = subprocess.run(["ffmpeg", "-hide_banner", "-i", crudo, "-af", "volumedetect", "-f", "null", "-"], capture_output=True, text=True)
            mx = next((float(l.split("max_volume:")[1].split("dB")[0]) for l in r.stderr.splitlines() if "max_volume" in l), pico)
            ff("-i", crudo, "-af", f"volume={pico - mx}dB", out)
            os.remove(crudo)
        rutas[nombre] = out
    return rutas

def mapa(plan):
    """Lista (sonido, segundo) a partir de los eventos del plan."""
    ev = plan["eventos"]
    titulos = sorted([e for e in ev if e["tipo"] == "titulo"], key=lambda e: e["t0"])
    out = []
    for e in ev:
        t = e["tipo"]
        if t == "broll": out.append(("whoosh", e["t0"]))
        elif t == "destello": out.append(("brillo", e["t"]))
        elif t == "flash": out.append(("whoosh", e["t"]))
        elif t == "titulo":
            extremo = e is titulos[0] or e is titulos[-1]
            out.append(("impacto" if extremo else "whoosh", e["t0"] + 0.05))
        elif t in ("acento", "icono", "imagen", "tarjeta", "pasos"): out.append(("pop", e["t0"] + 0.05))
        elif t == "cta": out.append(("tick", e["t0"] + 0.25))
        # zoom: sin sonido
    # evita encimar dos sonidos casi iguales
    out.sort(key=lambda x: x[1])
    final = []
    for n, s in out:
        if final and final[-1][0] == n and s - final[-1][1] < 0.35:
            continue
        final.append((n, s))
    return final

def main():
    import json
    ap = argparse.ArgumentParser()
    ap.add_argument("video"); ap.add_argument("plan")
    ap.add_argument("--salida"); ap.add_argument("--nivel", type=float, default=1.0)
    ap.add_argument("--musica")
    a = ap.parse_args()
    plan = json.load(open(a.plan, encoding="utf-8"))
    rutas = generar()
    sfx = []
    for n, s in mapa(plan):
        sfx += ["--sfx", f"{rutas[n]}@{max(0, s):.2f}"]
    salida = a.salida or os.path.splitext(a.video)[0] + ".sonido.mp4"
    cmd = [sys.executable, os.path.join(AQUI, "musica.py"), a.video, "--salida", salida, *sfx]
    if a.musica:
        cmd += ["--musica", a.musica]
    if a.nivel != 1.0:
        os.environ["KIT_NIVEL_SFX"] = str(a.nivel)
    print(f"[kit-editor-ia] {len(sfx)//2} sonidos sutiles (nivel {a.nivel})")
    sys.exit(subprocess.call(cmd))

if __name__ == "__main__":
    main()
