"""Dos usos:
  referencia  ref.mp4   -> mide el ritmo de un Reels que te gusta (cortes, duración por toma) y saca
                           una hoja de cuadros para que Claude lea colores, subtítulos y gancho.
  prueba      video.mp4 -> hoja de cuadros + duración para revisar una edición antes de entregarla.

Uso: python analizar.py referencia|prueba video.mp4 [--cuadros 12]
"""
import argparse, json, os, re, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from ek import need, probe, run, save

ap = argparse.ArgumentParser()
ap.add_argument("modo", choices=["referencia", "prueba"])
ap.add_argument("video"); ap.add_argument("--cuadros", type=int, default=12)
a = ap.parse_args()

info = probe(a.video)
base = os.path.splitext(a.video)[0]
n = a.cuadros
step = info["dur"] / n
sheet = base + f".{a.modo}.jpg"
cols = 4 if n >= 8 else n
rows = -(-n // cols)
run(["ffmpeg", "-y", "-v", "error", "-i", a.video, "-vf",
     f"fps=1/{step:.3f},scale=270:-2,tile={cols}x{rows}:padding=6:color=white", "-frames:v", "1", sheet])

rep = {"duracion": round(info["dur"], 2), "res": f"{info['w']}x{info['h']}", "hoja": sheet}
if a.modo == "referencia":
    need("ffmpeg")
    r = subprocess.run(["ffmpeg", "-i", a.video, "-vf", "select='gt(scene,0.28)',showinfo", "-f", "null", "-"],
                       capture_output=True, text=True)
    cuts = [float(x) for x in re.findall(r"pts_time:([0-9.]+)", r.stderr)]
    shots = [b - a_ for a_, b in zip([0.0] + cuts, cuts + [info["dur"]])]
    rep.update({
        "cortes": len(cuts),
        "segundos_por_toma": round(sum(shots) / len(shots), 2) if shots else info["dur"],
        "tiempos_de_corte": [round(c, 2) for c in cuts],
        "instruccion": "Mira la hoja de cuadros: describe tipografía, tamaño y posición de subtítulos, "
                       "colores, si hay gancho en pantalla y zooms. Replica ese ritmo con --pausa y textos.py.",
    })
save(rep, base + f".{a.modo}.json")
print(json.dumps(rep, ensure_ascii=False, indent=1))
