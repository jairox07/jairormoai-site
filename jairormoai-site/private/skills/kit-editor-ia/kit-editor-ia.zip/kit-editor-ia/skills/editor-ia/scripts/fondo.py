"""Recorta a la persona sin pantalla verde y la pone sobre otro fondo.
Opcional: una capa .ass (palabra de impacto) que queda DETRÁS de la persona.

Uso: python fondo.py video.mp4 --fondo imagen.jpg|"#080610"|blur [--detras impacto.ass] [--salida out.mp4]
Requiere: pip install "rembg[cpu]" pillow numpy  (la primera vez descarga el modelo de recorte)
Es el paso más lento: ~1-3 s por cuadro en CPU. Para pruebas usa --fps 15.
"""
import argparse, glob, os, shutil, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from ek import KIT, probe, run

ap = argparse.ArgumentParser()
ap.add_argument("video")
ap.add_argument("--fondo", default="blur")
ap.add_argument("--detras", help=".ass que se dibuja entre el fondo y la persona")
ap.add_argument("--fps", type=float, default=None)
ap.add_argument("--modelo", default="u2net_human_seg")
ap.add_argument("--salida")
a = ap.parse_args()

try:
    import numpy as np
    from PIL import Image, ImageFilter
    from rembg import new_session, remove
except ImportError:
    sys.exit('[kit-editor-ia] Falta rembg: pip install "rembg[cpu]" pillow numpy')

info = probe(a.video)
fps = a.fps or round(info["fps"]) or 30
tmp = tempfile.mkdtemp()
fr, bgdir, outdir = (os.path.join(tmp, x) for x in ("in", "bg", "out"))
for p in (fr, bgdir, outdir):
    os.makedirs(p)
run(["ffmpeg", "-v", "error", "-i", a.video, "-vf", f"fps={fps}", os.path.join(fr, "%05d.png")])
frames = sorted(glob.glob(os.path.join(fr, "*.png")))
W, H = info["w"], info["h"]

# Fondo por cuadro (fijo, color o desenfoque del propio cuadro)
fixed = None
if a.fondo.startswith("#"):
    fixed = Image.new("RGB", (W, H), a.fondo)
elif a.fondo != "blur":
    fixed = Image.open(a.fondo).convert("RGB")
    r = max(W / fixed.width, H / fixed.height)
    fixed = fixed.resize((int(fixed.width * r) + 1, int(fixed.height * r) + 1))
    l = (fixed.width - W) // 2; t = (fixed.height - H) // 2
    fixed = fixed.crop((l, t, l + W, t + H))

for f in frames:
    im = Image.open(f).convert("RGB")
    bg = fixed if fixed is not None else im.filter(ImageFilter.GaussianBlur(40))
    bg.save(os.path.join(bgdir, os.path.basename(f)))

# Si hay capa "detrás", se quema sobre el fondo antes de poner a la persona encima
if a.detras:
    fonts = os.path.join(os.path.dirname(KIT), "fonts").replace("\\", "/").replace(":", "\\:")
    ass = os.path.abspath(a.detras).replace("\\", "/").replace(":", "\\:")
    bgv = os.path.join(tmp, "bg.mp4")
    run(["ffmpeg", "-v", "error", "-framerate", str(fps), "-i", os.path.join(bgdir, "%05d.png"),
         "-vf", f"ass='{ass}':fontsdir='{fonts}'", "-pix_fmt", "rgb24", "-c:v", "png", "-f", "image2",
         os.path.join(bgdir, "t_%05d.png")])
    for f in glob.glob(os.path.join(bgdir, "t_*.png")):
        shutil.move(f, os.path.join(bgdir, os.path.basename(f)[2:]))

sess = new_session(a.modelo)
for i, f in enumerate(frames):
    im = Image.open(f).convert("RGB")
    cut = remove(im, session=sess)  # RGBA
    bg = Image.open(os.path.join(bgdir, os.path.basename(f))).convert("RGB")
    bg.paste(cut, (0, 0), cut)
    bg.save(os.path.join(outdir, os.path.basename(f)))
    if i % 30 == 0:
        print(f"  cuadro {i+1}/{len(frames)}")

out = a.salida or os.path.splitext(a.video)[0] + ".fondo.mp4"
cmd = ["ffmpeg", "-y", "-v", "error", "-framerate", str(fps), "-i", os.path.join(outdir, "%05d.png")]
if info["audio"]:
    cmd += ["-i", a.video, "-map", "0:v", "-map", "1:a", "-c:a", "aac", "-shortest"]
run(cmd + ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", out])
shutil.rmtree(tmp, ignore_errors=True)
print(f"OK {out}")
