"""Utilidades compartidas del Kit Editor IA (jairoromo.ai)."""
import json, os, re, shutil, subprocess, sys, unicodedata

KIT = os.path.dirname(os.path.abspath(__file__))

# Paleta de marca para textos en video
BLANCO = "&H00FFFFFF"
NEGRO = "&H00080610"
AZUL = "&H00FFA300"      # #00A3FF en BGR
MAGENTA = "&H00FF00FF"   # #FF00FF
MORADO = "&H00A8216B"    # #6B21A8


def need(cmd):
    if not shutil.which(cmd):
        sys.exit(f"[kit-editor-ia] Falta '{cmd}'. Corre el instalador o pídele a Claude: 'instala {cmd}'.")


def run(args, quiet=True):
    need(args[0])
    r = subprocess.run(args, capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"[kit-editor-ia] Error en {' '.join(args[:3])}...\n{r.stderr[-1500:]}")
    return r.stdout


def probe(path):
    out = run(["ffprobe", "-v", "error", "-show_entries",
               "stream=codec_type,width,height,r_frame_rate:format=duration",
               "-of", "json", path])
    d = json.loads(out)
    v = next((s for s in d["streams"] if s["codec_type"] == "video"), {})
    a = any(s["codec_type"] == "audio" for s in d["streams"])
    num, den = (v.get("r_frame_rate", "30/1").split("/") + ["1"])[:2]
    return {
        "dur": float(d["format"]["duration"]),
        "w": int(v.get("width", 1080)), "h": int(v.get("height", 1920)),
        "fps": float(num) / float(den or 1), "audio": a,
    }


def norm(t):
    t = unicodedata.normalize("NFD", t.lower())
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    return re.sub(r"[^a-z0-9ñ ]+", "", t).strip()


def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def save(obj, p):
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


def ts_ass(t):
    t = max(0.0, t)
    h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def ass_header(w, h, styles):
    base = (
        "[Script Info]\nScriptType: v4.00+\nWrapStyle: 0\nScaledBorderAndShadow: yes\n"
        f"PlayResX: {w}\nPlayResY: {h}\n\n[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
        "Alignment, MarginL, MarginR, MarginV, Encoding\n"
    )
    for s in styles:
        base += s + "\n"
    return base + "\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"


def esc(t):
    return t.replace("{", "(").replace("}", ")").replace("\n", "\\N")
