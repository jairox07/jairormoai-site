# © 2026 Jairo Romo · jairoromo.ai · Kit Editor IA — licencia de uso personal, ver LICENCIA.txt. Prohibido compartir o revender.
"""Motor de estilos v2 · Kit Editor IA (jairoromo.ai)

Renderiza un video ya cortado con un "plan" de estilo: subtítulos, títulos gigantes
(metálicos o planos, delante o DETRÁS de la persona), acentos en cursiva, escena de
pasos en vidrio, tarjetas tipo notificación, píldora de CTA, zooms y transiciones.

Uso:
  python motor.py video.editado.mp4 video.editado.palabras.json plan.json --salida final.mp4
          [--desde 0 --hasta 0] [--fps 0]

El plan es JSON (lo escribe Claude según el estilo elegido). Ver estilos/*.json.
Todo corre local: ffmpeg + Pillow + numpy (+ rembg solo si un título va detrás).
"""
import argparse, json, math, os, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

AQUI = os.path.dirname(os.path.abspath(__file__))
FUENTES = os.environ.get("KIT_FUENTES", os.path.join(os.path.dirname(AQUI), "fonts"))

# ---------------------------------------------------------------- utilidades
def fuente(nombre, tam, var=None):
    f = ImageFont.truetype(nombre if os.path.isabs(nombre) else os.path.join(FUENTES, nombre), tam)
    if var:
        try:
            f.set_variation_by_name(var)
        except Exception:
            try:
                f.set_variation_by_axes(var if isinstance(var, list) else [var])
            except Exception:
                pass
    return f

def hexa(c, a=255):
    c = c.lstrip("#")
    return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), a)

def suave(x):  # easing 0..1
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)

def opacidad(t, t0, t1, fin=0.22, fout=0.22):
    if t < t0 or t > t1:
        return 0.0
    a = 1.0
    if fin > 0:
        a = min(a, suave((t - t0) / fin))
    if fout > 0:
        a = min(a, suave((t1 - t) / fout))
    return a

def probe(v):
    o = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                        "stream=width,height,r_frame_rate:format=duration", "-of", "json", v],
                       capture_output=True, text=True, check=True).stdout
    j = json.loads(o)
    s = j["streams"][0]
    n, d = s["r_frame_rate"].split("/")
    return int(s["width"]), int(s["height"]), float(n) / float(d), float(j["format"]["duration"])

def medir(draw, txt, f):
    b = draw.textbbox((0, 0), txt, font=f)
    return b[2] - b[0], b[3] - b[1], b

_DUMMY = ImageDraw.Draw(Image.new("L", (8, 8)))

def capa_texto(txt, f, color=(255, 255, 255, 255), sombra=0.55, rad=10, track=0):
    """Imagen RGBA con el texto y sombra suave. Devuelve (img, ox, oy) con el centro óptico."""
    w, h, b = medir(_DUMMY, txt, f)
    w += track * max(0, len(txt) - 1)
    pad = rad * 3 + 6
    W, H = int(w + pad * 2), int(h + pad * 2)
    m = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(m)
    if track:
        x = pad
        for ch in txt:
            d.text((x - b[0], pad - b[1]), ch, font=f, fill=255)
            x += medir(_DUMMY, ch, f)[0] + track
    else:
        d.text((pad - b[0], pad - b[1]), txt, font=f, fill=255)
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if sombra > 0:
        sm = m.filter(ImageFilter.GaussianBlur(rad)).point(lambda v: int(v * sombra))
        out.paste((0, 0, 0, 255), (0, int(rad * 0.5)), sm)
    fill = Image.new("RGBA", (W, H), color)
    out = Image.alpha_composite(out, Image.composite(fill, Image.new("RGBA", (W, H), (0, 0, 0, 0)), m))
    return out

def poner(base, img, cx, cy, alpha=1.0):
    """Pega img (RGBA) centrada en (cx, cy) sobre base (RGBA) con opacidad."""
    if alpha <= 0.003 or img is None:
        return
    if alpha < 0.999:
        a = img.getchannel("A").point(lambda v: int(v * alpha))
        img = img.copy()
        img.putalpha(a)
    x, y = int(round(cx - img.width / 2)), int(round(cy - img.height / 2))
    # recortar a los bordes
    sx, sy = max(0, -x), max(0, -y)
    ex, ey = min(img.width, base.width - x), min(img.height, base.height - y)
    if ex <= sx or ey <= sy:
        return
    if sx or sy or ex < img.width or ey < img.height:
        img = img.crop((sx, sy, ex, ey))
    base.alpha_composite(img, (x + sx, y + sy))

def redondeado(w, h, r, fill, borde=None):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w - 1, h - 1), r, fill=fill, outline=borde, width=2 if borde else 0)
    return im

def vidrio(base, box, r, tinte=(14, 16, 22, 170), borde=(255, 255, 255, 34), blur=18):
    """Panel de vidrio esmerilado: desenfoca lo que hay detrás dentro de box."""
    x0, y0, x1, y1 = [int(v) for v in box]
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(base.width, x1), min(base.height, y1)
    if x1 - x0 < 4 or y1 - y0 < 4:
        return
    reg = base.crop((x0, y0, x1, y1)).filter(ImageFilter.GaussianBlur(blur))
    reg = Image.alpha_composite(reg, Image.new("RGBA", reg.size, tinte))
    mask = Image.new("L", reg.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, reg.width - 1, reg.height - 1), r, fill=255)
    base.paste(reg, (x0, y0), mask)
    ImageDraw.Draw(base).rounded_rectangle((x0, y0, x1 - 1, y1 - 1), r, outline=borde, width=2)

# ---------------------------------------------------------------- recorte de persona
class Recorte:
    def __init__(self, fija=None):
        self.s = None
        self.cache = {}
        self.fija = Image.open(fija).convert("L") if fija else None

    def mascara(self, frame_img, clave):
        if self.fija is not None:
            if self.fija.size != frame_img.size:
                self.fija = self.fija.resize(frame_img.size)
            return self.fija
        if clave in self.cache:
            return self.cache[clave]
        if self.s is None:
            try:
                from rembg import new_session, remove
            except ImportError:
                sys.exit('[kit-editor-ia] Falta rembg: pip install "rembg[cpu]"')
            self._remove = remove
            self.s = new_session("u2net_human_seg")
        pequeño = frame_img.convert("RGB").resize((frame_img.width // 3, frame_img.height // 3))
        m = self._remove(pequeño, session=self.s, only_mask=True)
        m = m.filter(ImageFilter.GaussianBlur(1.5)).resize(frame_img.size, Image.BILINEAR)
        if len(self.cache) > 6:
            self.cache.clear()
        self.cache[clave] = m
        return m

# ---------------------------------------------------------------- elementos
class Titulo:
    """Palabra gigante. estilo: metal | blanco | color. detras: la persona queda delante."""
    def __init__(self, ev, W, H, plan):
        self.ev = ev
        st = plan.get("titulo", {})
        self.detras = ev.get("detras", st.get("detras", True))
        txt = ev["texto"].upper() if ev.get("mayus", True) else ev["texto"]
        fam = ev.get("fuente", st.get("fuente", "Anton-Regular.ttf"))
        ancho = ev.get("ancho", st.get("ancho", 0.9)) * W
        tam = ev.get("tam", st.get("tam", 330))
        var = ev.get("var", st.get("var"))
        f = fuente(fam, tam, var)
        while medir(_DUMMY, txt, f)[0] > ancho and tam > 60:
            tam -= 10
            f = fuente(fam, tam, var)
        w, h, b = medir(_DUMMY, txt, f)
        pad = 60
        Wt, Ht = w + pad * 2, h + pad * 2
        m = Image.new("L", (Wt, Ht), 0)
        ImageDraw.Draw(m).text((pad - b[0], pad - b[1]), txt, font=f, fill=255)
        estilo = ev.get("estilo", st.get("estilo", "metal"))
        self.img = None
        if estilo == "metal" and not var and ev.get("cromo", st.get("cromo", True)):
            self.img = self._cromo3d(txt, fam, w, h, ancho, pad, Wt, Ht)
        if self.img is not None:
            pass
        elif estilo == "metal":
            grad = np.zeros((Ht, 1, 3), np.float32)
            stops = [(0.0, (252, 252, 254)), (0.38, (205, 208, 215)), (0.5, (150, 154, 163)),
                     (0.56, (236, 238, 242)), (0.8, (160, 164, 172)), (1.0, (222, 224, 229))]
            ys = np.linspace(0, 1, Ht)
            y0 = pad / Ht
            y1 = (pad + h) / Ht
            yy = np.clip((ys - y0) / max(1e-3, (y1 - y0)), 0, 1)
            for c in range(3):
                grad[:, 0, c] = np.interp(yy, [s[0] for s in stops], [s[1][c] for s in stops])
            fill = Image.fromarray(np.repeat(grad, Wt, axis=1).astype(np.uint8), "RGB").convert("RGBA")
        else:
            fill = Image.new("RGBA", (Wt, Ht), hexa(ev.get("color", st.get("color", "#FFFFFF"))))
        if self.img is None:
            self._plano(m, fill, Wt, Ht)
        self.cx = ev.get("x", st.get("x", 0.5)) * W
        self.cy = ev.get("y", st.get("y", 0.25)) * H
        self.niveles = {}

    def _cromo3d(self, txt, fam, w, h, ancho, pad, Wt, Ht):
        """Cromo 3D real (Three.js). Devuelve la imagen lista o None para usar el cromo plano."""
        try:
            import cromo
            ruta = cromo.renderizar(txt, os.path.join(FUENTES, fam))
        except Exception:
            ruta = None
        if not ruta:
            return None
        c = Image.open(ruta).convert("RGBA")
        esc = min(h * 1.28 / c.height, ancho / c.width)
        c = c.resize((max(1, int(c.width * esc)), max(1, int(c.height * esc))), Image.LANCZOS)
        P = 70
        Wc, Hc = c.width + P * 2, c.height + P * 2
        al = c.getchannel("A")
        base = Image.new("RGBA", (Wc, Hc), (0, 0, 0, 0))
        sombra = Image.new("L", (Wc, Hc), 0); sombra.paste(al, (P, P + 12))
        base.paste((0, 0, 0, 255), (0, 0), sombra.filter(ImageFilter.GaussianBlur(16)).point(lambda v: int(v * 0.45)))
        brillo = Image.new("L", (Wc, Hc), 0); brillo.paste(al, (P, P))
        base.paste((255, 255, 255, 255), (0, 0), brillo.filter(ImageFilter.GaussianBlur(14)).point(lambda v: int(v * 0.30)))
        base.alpha_composite(c, (P, P))
        return base

    def _plano(self, m, fill, Wt, Ht):
        txtimg = Image.new("RGBA", (Wt, Ht), (0, 0, 0, 0))
        sh = m.filter(ImageFilter.GaussianBlur(16)).point(lambda v: int(v * 0.45))
        txtimg.paste((0, 0, 0, 255), (0, 14), sh)
        txtimg = Image.alpha_composite(txtimg, Image.composite(fill, Image.new("RGBA", (Wt, Ht), (0, 0, 0, 0)), m))
        self.img = txtimg

    def version(self, prog):  # prog 0..1 de entrada/salida -> desenfoque + escala
        nivel = int(round((1 - prog) * 4))  # 0..4
        if nivel not in self.niveles:
            if nivel == 0:
                self.niveles[0] = self.img
            else:
                esc = 1 + 0.03 * nivel
                im = self.img.resize((int(self.img.width * esc), int(self.img.height * esc)))
                self.niveles[nivel] = im.filter(ImageFilter.GaussianBlur(nivel * 4))
        return self.niveles[nivel]

    def dibujar(self, base, t, recorte, clave):
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.3, 0.35)
        if a <= 0:
            return False
        capa = Image.new("RGBA", base.size, (0, 0, 0, 0))
        poner(capa, self.version(a), self.cx, self.cy, a)
        if self.detras:
            m = recorte.mascara(base, clave)
            inv = Image.eval(m, lambda v: 255 - v)
            al = Image.composite(capa.getchannel("A"), Image.new("L", base.size, 0), inv)
            capa.putalpha(al)
        base.alpha_composite(capa)
        return True

class Acento:
    """Palabra o frase en cursiva elegante (o cualquier fuente) con entrada suave hacia arriba."""
    def __init__(self, ev, W, H, plan):
        st = plan.get("acento", {})
        self.ev = ev
        f = fuente(ev.get("fuente", st.get("fuente", "PlayfairDisplay-Italic[wght].ttf")),
                   ev.get("tam", st.get("tam", 104)), st.get("var", "Italic"))
        col = hexa(ev.get("color", st.get("color", "#FFFFFF")))
        self.img = capa_texto(ev["texto"], f, col, sombra=0.6, rad=12)
        self.cx = ev.get("x", st.get("x", 0.5)) * W
        self.cy = ev.get("y", st.get("y", 0.70)) * H

    def dibujar(self, base, t):
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.25, 0.25)
        if a <= 0:
            return
        dy = (1 - suave(min(1, (t - ev["t0"]) / 0.3))) * 24
        poner(base, self.img, self.cx, self.cy + dy, a)

class Pasos:
    """Escena de vidrio desenfocado con pasos que entran cuando se dicen, unidos por una línea punteada."""
    def __init__(self, ev, W, H, plan):
        st = plan.get("pasos", {})
        self.ev, self.W, self.H = ev, W, H
        self.f = fuente(st.get("fuente", "PlayfairDisplay-Italic[wght].ttf"), st.get("tam", 66), "Italic")
        self.fh = fuente(st.get("fuente_titulo", "Inter[opsz,wght].ttf"), 34, "Medium")
        self.color = hexa(st.get("punto", "#4DA3FF"))
        self.items = []
        n = len(ev["items"])
        for i, it in enumerate(ev["items"]):
            x = (0.34 if i % 2 == 0 else 0.52) * W
            y = (0.30 + i * (0.42 / max(1, n - 1))) * H
            img = capa_texto(it["texto"], self.f, (255, 255, 255, 255), sombra=0.5, rad=10)
            self.items.append((it["t"], x, y, img))
        self.titulo = capa_texto(ev.get("titulo", ""), self.fh, (220, 224, 235, 255), 0.4, 6, track=6) if ev.get("titulo") else None
        r = 11
        g = Image.new("RGBA", (r * 8, r * 8), (0, 0, 0, 0))
        dg = ImageDraw.Draw(g)
        c = r * 4
        dg.ellipse((c - r * 2.4, c - r * 2.4, c + r * 2.4, c + r * 2.4), fill=self.color[:3] + (120,))
        g = g.filter(ImageFilter.GaussianBlur(7))
        dg = ImageDraw.Draw(g)
        dg.ellipse((c - r, c - r, c + r, c + r), fill=(235, 245, 255, 255))
        self.punto = g

    def fondo(self, base, t):
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.18, 0.18)
        if a <= 0:
            return 0
        pequeño = base.resize((base.width // 8, base.height // 8)).filter(ImageFilter.GaussianBlur(5))
        bl = pequeño.resize(base.size, Image.BILINEAR)
        bl = Image.alpha_composite(bl, Image.new("RGBA", base.size, (8, 10, 16, 150)))
        # barras verticales sutiles tipo vidrio estriado
        ov = Image.new("RGBA", base.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(ov)
        for x in range(0, base.width, 90):
            d.rectangle((x, 0, x + 1, base.height), fill=(255, 255, 255, 14))
        bl.alpha_composite(ov)
        if a < 1:
            bl = Image.blend(base, bl, a)
        base.paste(bl)
        return a

    def dibujar(self, base, t):
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.25, 0.2)
        if a <= 0:
            return
        if self.titulo:
            poner(base, self.titulo, self.W * 0.5, self.H * 0.22, a * 0.9)
        ov = Image.new("RGBA", base.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(ov)
        prev = None
        for (ti, x, y, img) in self.items:
            if t < ti:
                break
            k = suave((t - ti) / 0.3)
            px = x - 40
            if prev is not None:  # línea punteada desde el punto anterior
                (x0, y0) = prev
                n = 18
                for j in range(int(n * k)):
                    if j % 2 == 0:
                        p0 = (x0 + (px - x0) * j / n, y0 + (y - y0) * j / n)
                        p1 = (x0 + (px - x0) * (j + 1) / n, y0 + (y - y0) * (j + 1) / n)
                        d.line([p0, p1], fill=(200, 215, 240, int(150 * a)), width=2)
            poner(ov, self.punto, px, y, a * k)
            poner(ov, img, px + 30 + img.width / 2 - 34, y + (1 - k) * 18, a * k)
            prev = (px, y)
        base.alpha_composite(ov)

class Tarjeta:
    """Tarjeta tipo notificación: vidrio oscuro, ícono en círculo y dos líneas (una de acento)."""
    def __init__(self, ev, W, H, plan, codepoints):
        st = plan.get("tarjeta", {})
        self.ev, self.W, self.H = ev, W, H
        self.acento = hexa(ev.get("color", st.get("color", "#38BDF8")))
        ft = fuente(st.get("fuente", "Montserrat[wght].ttf"), st.get("tam", 44), st.get("var", "ExtraBold"))
        l1, l2 = ev.get("l1", "").upper(), ev.get("l2", "").upper()
        ac = ev.get("acento_linea", 2)
        c1 = self.acento if ac == 1 else (255, 255, 255, 255)
        c2 = self.acento if ac == 2 else (255, 255, 255, 255)
        w1 = medir(_DUMMY, l1, ft)[0]
        w2 = medir(_DUMMY, l2, ft)[0] if l2 else 0
        tw = max(w1, w2)
        self.r_ic = 54
        pad, gap = 26, 24
        self.w = int(pad + self.r_ic * 2 + gap + tw + pad + 10)
        self.h = int(st.get("alto", 150))
        im = Image.new("RGBA", (self.w, self.h), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        cx, cy = pad + self.r_ic, self.h // 2
        d.ellipse((cx - self.r_ic, cy - self.r_ic, cx + self.r_ic, cy + self.r_ic),
                  fill=(40, 48, 58, 230), outline=self.acento[:3] + (90,), width=3)
        icono = ev.get("icono", "auto_awesome")
        cp = codepoints.get(icono)
        if cp:
            fi = fuente("MaterialSymbolsRounded.ttf", 58)
            g = chr(int(cp, 16))
            bw, bh, bb = medir(_DUMMY, g, fi)
            d.text((cx - bw / 2 - bb[0], cy - bh / 2 - bb[1]), g, font=fi, fill=self.acento[:3] + (235,))
        tx = pad + self.r_ic * 2 + gap
        lh = medir(_DUMMY, "HÁg", ft)[1]
        if l2:
            y1 = cy - lh - 2
            y2 = cy + 4
        else:
            y1 = cy - lh / 2
        b1 = d.textbbox((0, 0), l1, font=ft)
        d.text((tx - b1[0], y1 - b1[1] + 4), l1, font=ft, fill=c1)
        if l2:
            b2 = d.textbbox((0, 0), l2, font=ft)
            d.text((tx - b2[0], y2 - b2[1] + 4), l2, font=ft, fill=c2)
        self.contenido = im
        self.cx = W / 2
        self.cy = st.get("y", 0.085) * H + self.h / 2

    def dibujar(self, base, t):
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.2, 0.25)
        if a <= 0:
            return
        k = suave(min(1, (t - ev["t0"]) / 0.25))
        esc = 0.92 + 0.08 * k
        w, h = int(self.w * esc), int(self.h * esc)
        x0, y0 = self.cx - w / 2, self.cy - h / 2
        if a > 0.6:
            vidrio(base, (x0, y0, x0 + w, y0 + h), 30, tinte=(24, 26, 32, int(190 * a)), borde=(255, 255, 255, int(40 * a)))
        else:
            poner(base, redondeado(w, h, 30, (24, 26, 32, int(170 * a))), self.cx, self.cy)
        cont = self.contenido if esc > 0.999 else self.contenido.resize((w, h))
        poner(base, cont, self.cx, self.cy, a)

class Pildora:
    """CTA en píldora oscura de vidrio con un ✳ de color y texto en cursiva."""
    def __init__(self, ev, W, H, plan):
        st = plan.get("pildora", {})
        self.ev, self.W, self.H = ev, W, H
        f = fuente(st.get("fuente", "PlayfairDisplay-Italic[wght].ttf"), st.get("tam", 50), st.get("var", "Medium Italic"))
        fs = fuente("Inter[opsz,wght].ttf", 50, "Bold")
        txt = ev["texto"]
        tw, th, b = medir(_DUMMY, txt, f)
        self.w, self.h = int(tw + 140), 110
        im = Image.new("RGBA", (self.w, self.h), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        col = hexa(st.get("color", "#FF8A3D"))
        ax, ay, r = 58, self.h / 2, 15
        for ang in range(0, 180, 45):
            dx, dy = r * math.cos(math.radians(ang)), r * math.sin(math.radians(ang))
            d.line([(ax - dx, ay - dy), (ax + dx, ay + dy)], fill=col, width=5)
        d.text((92 - b[0], self.h / 2 - th / 2 - b[1]), txt, font=f, fill=(245, 245, 248, 255))
        self.cont = im
        self.cx = W / 2
        self.cy = ev.get("y", st.get("y", 0.73)) * H

    def dibujar(self, base, t):
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.3, 0.3)
        if a <= 0:
            return
        dy = (1 - suave(min(1, (t - ev["t0"]) / 0.35))) * 30
        x0, y0 = self.cx - self.w / 2, self.cy - self.h / 2 + dy
        vidrio(base, (x0, y0, x0 + self.w, y0 + self.h), self.h // 2, tinte=(18, 18, 22, int(200 * a)),
               borde=(255, 255, 255, int(55 * a)))
        poner(base, self.cont, self.cx, self.cy + dy, a)

# ---------------------------------------------------------------- subtítulos
def _norm(t):
    return "".join(ch for ch in t.lower() if ch.isalnum() or ch in "áéíóúüñ")

class Subtitulos:
    """Subtítulos con estilo propio por plantilla.
    modo: frase (bloques que se revelan palabra por palabra) | palabra (una a la vez) | ninguno
    Opciones: fuente, var, tam, y, color, mayusculas, tenue (0 = las que vienen no se ven),
    activo_color (karaoke), claves + clave_color/clave_fuente/clave_var/clave_brillo,
    contorno + contorno_color, sombra, caja (color con alfa detrás), pop (palabra que rebota),
    max_palabras, max_car, interlineado."""
    def __init__(self, palabras, W, H, plan):
        st = plan.get("subtitulos", {})
        self.st = st
        self.modo = st.get("modo", "frase")
        self.W, self.H = W, H
        self.y = st.get("y", 0.62) * H
        self.mayus = st.get("mayusculas", self.modo == "palabra")
        self.f = fuente(st.get("fuente", "Inter[opsz,wght].ttf"), st.get("tam", 44), st.get("var", "Medium"))
        self.fc = fuente(st.get("clave_fuente", st.get("fuente", "Inter[opsz,wght].ttf")),
                         st.get("clave_tam", st.get("tam", 44)), st.get("clave_var", st.get("var", "Medium")))
        self.tenue = st.get("tenue", 0.35)
        self.max_car = st.get("max_car", 24)
        self.max_pal = st.get("max_palabras", 7)
        self.color = hexa(st.get("color", "#FFFFFF"))
        self.activo = hexa(st["activo_color"]) if st.get("activo_color") else None
        self.claves = {_norm(c) for c in st.get("claves", [])}
        self.clave_color = hexa(st["clave_color"]) if st.get("clave_color") else None
        self.brillo = st.get("clave_brillo", False)
        self.contorno = st.get("contorno", 0)
        self.contorno_color = hexa(st.get("contorno_color", "#000000"))
        self.sombra = st.get("sombra", 0.6)
        self.caja = hexa(st["caja"][:7], int(st["caja"][7:9], 16) if len(st["caja"]) > 7 else 200) if st.get("caja") else None
        self.pop = st.get("pop", False)
        self.ocultar = st.get("ocultar", [])
        self.ws = [w for w in palabras if w["w"].strip()]
        self.bloques = self._bloques()
        self.cache = {}
        self.pcache = {}

    def _bloques(self):
        bl, cur = [], []
        for w in self.ws:
            cur.append(w)
            fin = w["w"].rstrip()[-1:] in ".?!,"
            if len(cur) >= self.max_pal or (fin and len(cur) >= min(3, self.max_pal)) or w["w"].rstrip()[-1:] in ".?!":
                bl.append(cur)
                cur = []
        if cur:
            bl.append(cur)
        out = []
        for i, b in enumerate(bl):
            t0 = b[0]["s"]
            nxt = bl[i + 1][0]["s"] if i + 1 < len(bl) else b[-1]["e"] + 0.6
            out.append((t0, min(nxt, b[-1]["e"] + 1.2), b))
        return out

    def _t(self, w):
        t = w["w"].strip()
        if self.st.get("sin_puntuacion", self.modo == "palabra"):
            t = t.strip(",.;:")
        return t.upper() if self.mayus else t

    def _es_clave(self, w):
        return _norm(w["w"]) in self.claves

    def _palabra(self, txt, clave, activo):
        k = (txt, clave, activo)
        if k in self.pcache:
            return self.pcache[k]
        f = self.fc if clave else self.f
        col = self.color
        if clave and self.clave_color:
            col = self.clave_color
        elif activo and self.activo:
            col = self.activo
        w, h, b = medir(_DUMMY, txt, f)
        sw = self.contorno
        pad = 24 + sw
        asc = f.getmetrics()[0]
        im = Image.new("RGBA", (int(w + pad * 2), int(asc + f.getmetrics()[1] + pad * 2)), (0, 0, 0, 0))
        if clave and self.brillo and self.clave_color:
            g = Image.new("L", im.size, 0)
            ImageDraw.Draw(g).text((pad - b[0], pad + asc), txt, font=f, fill=255, anchor="ls", stroke_width=sw + 6)
            g = g.filter(ImageFilter.GaussianBlur(14)).point(lambda v: int(v * 0.9))
            im.paste(col[:3] + (255,), (0, 0), g)
        ImageDraw.Draw(im).text((pad - b[0], pad + asc), txt, font=f, fill=col, anchor="ls",
                                stroke_width=sw, stroke_fill=self.contorno_color if sw else None)
        self.pcache[k] = (im, pad, asc, w)
        return self.pcache[k]

    def _lineas(self, b):
        txts = [self._t(w) for w in b]
        total = " ".join(txts)
        if len(total) <= self.max_car or len(b) < 2:
            return [list(range(len(b)))]
        mejor, idx = 1e9, 1
        for k in range(1, len(b)):
            a = len(" ".join(txts[:k]))
            c = len(" ".join(txts[k:]))
            if max(a, c) < mejor:
                mejor, idx = max(a, c), k
        return [list(range(idx)), list(range(idx, len(b)))]

    def _render(self, bi, activo):
        clave = (bi, activo)
        if clave in self.cache:
            return self.cache[clave]
        b = self.bloques[bi][2]
        lineas = self._lineas(b)
        esp = medir(_DUMMY, " ", self.f)[0] + 6 + self.contorno
        lh = int(medir(_DUMMY, "HÁgy", self.f)[1] * self.st.get("interlineado", 1.3)) + self.contorno * 2
        piezas, anchos = [], []
        for ln in lineas:
            fila = []
            for i in ln:
                pw = self._palabra(self._t(b[i]), self._es_clave(b[i]), i == activo)
                fila.append((i, pw))
            piezas.append(fila)
            anchos.append(sum(p[1][3] for p in fila) + esp * (len(fila) - 1))
        padc = 34 if self.caja else 0
        Wc, Hc = int(max(anchos) + 80 + padc * 2), int(lh * len(lineas) + 60 + padc)
        img = Image.new("RGBA", (Wc, Hc), (0, 0, 0, 0))
        capa = Image.new("RGBA", (Wc, Hc), (0, 0, 0, 0))
        for li, fila in enumerate(piezas):
            x = (Wc - anchos[li]) / 2
            ybase = 30 + padc / 2 + li * lh
            for (i, (im, pad, asc, w)) in fila:
                if i > activo and self.tenue <= 0:
                    x += w + esp
                    continue
                pi = im
                if i > activo and self.tenue < 1:
                    pi = im.copy()
                    pi.putalpha(im.getchannel("A").point(lambda v: int(v * self.tenue)))
                capa.alpha_composite(pi, (int(x - pad), int(ybase - pad)))
                x += w + esp
        if self.caja:
            bb = capa.getbbox()
            if bb:
                d = ImageDraw.Draw(img)
                d.rounded_rectangle((bb[0] - padc + 14, bb[1] - 18, bb[2] + padc - 14, bb[3] + 18), 22, fill=self.caja)
        if self.sombra > 0:
            sh = capa.getchannel("A").filter(ImageFilter.GaussianBlur(9)).point(lambda v: int(v * self.sombra))
            img.paste((0, 0, 0, 255), (0, 4), sh) if not self.caja else None
        img.alpha_composite(capa)
        if len(self.cache) > 400:
            self.cache.clear()
        self.cache[clave] = img
        return img

    def dibujar(self, base, t):
        if self.modo == "ninguno":
            return
        for (a, b) in self.ocultar:
            if a <= t <= b:
                return
        if self.modo == "palabra":
            for w in self.ws:
                if w["s"] - 0.02 <= t <= max(w["e"], w["s"] + 0.25) + 0.05:
                    k = ("p", w["s"])
                    if k not in self.cache:
                        self.bloques_tmp = None
                        im, pad, asc, ww = self._palabra(self._t(w), self._es_clave(w), True)
                        out = Image.new("RGBA", im.size, (0, 0, 0, 0))
                        if self.sombra > 0:
                            sh = im.getchannel("A").filter(ImageFilter.GaussianBlur(9)).point(lambda v: int(v * self.sombra))
                            out.paste((0, 0, 0, 255), (0, 4), sh)
                        out.alpha_composite(im)
                        self.cache[k] = out
                    img = self.cache[k]
                    if self.pop:
                        e = (t - w["s"]) / 0.12
                        if e < 1:
                            esc = 0.75 + 0.4 * suave(e) if e < 0.7 else 1.05 - 0.05 * suave((e - 0.7) / 0.3)
                            img = img.resize((max(1, int(img.width * esc)), max(1, int(img.height * esc))))
                    poner(base, img, self.W / 2, self.y)
                    return
            return
        for bi, (t0, t1, b) in enumerate(self.bloques):
            if t0 - 0.05 <= t <= t1:
                act = -1
                for i, w in enumerate(b):
                    if t >= w["s"] - 0.03:
                        act = i
                img = self._render(bi, act)
                a = min(1.0, (t - t0 + 0.05) / 0.12)
                poner(base, img, self.W / 2, self.y, a)
                return

class Icono:
    """Ícono grande (Material Symbols) en círculo de color que entra con rebote; etiqueta opcional."""
    def __init__(self, ev, W, H, plan, codepoints):
        st = plan.get("icono", {})
        self.ev, self.W, self.H = ev, W, H
        r = ev.get("radio", st.get("radio", 120))
        col = hexa(ev.get("color", st.get("color", "#FFD400")))
        fondo = ev.get("fondo", st.get("fondo", "circulo"))
        im = Image.new("RGBA", (r * 2 + 60, r * 2 + 60), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        c = r + 30
        if fondo == "circulo":
            sh = Image.new("L", im.size, 0)
            ImageDraw.Draw(sh).ellipse((c - r, c - r + 10, c + r, c + r + 10), fill=150)
            im.paste((0, 0, 0, 255), (0, 0), sh.filter(ImageFilter.GaussianBlur(14)))
            d.ellipse((c - r, c - r, c + r, c + r), fill=col, outline=(255, 255, 255, 255), width=8)
            gcol = hexa(ev.get("icono_color", st.get("icono_color", "#111111")))
        else:
            gcol = col
        cp = codepoints.get(ev["icono"])
        if cp:
            fi = fuente("MaterialSymbolsRounded.ttf", int(r * 1.25))
            g = chr(int(cp, 16))
            if fondo != "circulo":
                gl = Image.new("L", im.size, 0)
                ImageDraw.Draw(gl).text((c, c), g, font=fi, fill=255, anchor="mm")
                im.paste((0, 0, 0, 255), (0, 6), gl.filter(ImageFilter.GaussianBlur(10)).point(lambda v: int(v * 0.6)))
            ImageDraw.Draw(im).text((c, c), g, font=fi, fill=gcol, anchor="mm")
        if ev.get("etiqueta"):
            fe = fuente(st.get("etiqueta_fuente", "Montserrat[wght].ttf"), st.get("etiqueta_tam", 40), st.get("etiqueta_var", "Bold"))
            et = capa_texto(ev["etiqueta"].upper(), fe, (255, 255, 255, 255), 0.7, 8)
            W2 = max(im.width, et.width)
            full = Image.new("RGBA", (W2, im.height + et.height - 20), (0, 0, 0, 0))
            full.alpha_composite(im, ((W2 - im.width) // 2, 0))
            full.alpha_composite(et, ((W2 - et.width) // 2, im.height - 30))
            im = full
        self.img = im
        self.cx = ev.get("x", 0.5) * W
        self.cy = ev.get("y", 0.2) * H

    def dibujar(self, base, t):
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.08, 0.2)
        if a <= 0:
            return
        e = (t - ev["t0"]) / 0.28
        esc = 1.0
        if e < 1:
            esc = 0.3 + 0.9 * suave(e / 0.6) if e < 0.6 else 1.2 - 0.2 * suave((e - 0.6) / 0.4)
        img = self.img if abs(esc - 1) < 0.01 else self.img.resize((max(1, int(self.img.width * esc)), max(1, int(self.img.height * esc))))
        if ev.get("giro"):
            img = img.rotate(ev["giro"], resample=Image.BICUBIC, expand=True)
        poner(base, img, self.cx, self.cy, a)


def cubrir(img, W, H):
    """Escala y recorta img para llenar W x H (como object-fit: cover)."""
    r = max(W / img.width, H / img.height)
    im = img.resize((max(W, int(img.width * r + 0.5)), max(H, int(img.height * r + 0.5))), Image.LANCZOS)
    x, y = (im.width - W) // 2, (im.height - H) // 2
    return im.crop((x, y, x + W, y + H))

class BRoll:
    """Toma de apoyo a pantalla completa (video o imagen). La voz sigue sonando.
    archivo: clip.mp4 | foto.jpg | "auto" (portada animada con el título y los colores del estilo).
    Las imágenes llevan movimiento lento (Ken Burns)."""
    def __init__(self, ev, W, H, plan, base_dir):
        self.ev, self.W, self.H = ev, W, H
        self.t0, self.t1 = ev["t0"], ev["t1"]
        arch = ev.get("archivo", "auto")
        self.modo = "auto"
        self.proc = None
        self.ultimo = None
        if arch != "auto":
            ruta = arch if os.path.isabs(arch) else os.path.join(base_dir, arch)
            if not os.path.exists(ruta):
                print(f"  [aviso] no encuentro el B-roll {ruta}; uso portada automática")
            elif os.path.splitext(ruta)[1].lower() in (".jpg", ".jpeg", ".png", ".webp"):
                self.modo = "imagen"
                self.img = cubrir(Image.open(ruta).convert("RGB"), int(W * 1.15), int(H * 1.15))
            else:
                self.modo = "video"
                self.ruta = ruta
        if self.modo == "auto":
            st = plan.get("portada", {})
            c1, c2 = hexa(st.get("color1", "#101018")), hexa(st.get("color2", "#2A1E5C"))
            yy = np.linspace(0, 1, H)[:, None, None]
            g = (np.array(c1[:3]) * (1 - yy) + np.array(c2[:3]) * yy).astype(np.uint8)
            self.fondo = Image.fromarray(np.repeat(g, W, axis=1), "RGB")
            fam = st.get("fuente", plan.get("titulo", {}).get("fuente", "Anton-Regular.ttf"))
            tam = st.get("tam", 150)
            f = fuente(fam, tam, st.get("var"))
            lineas = ev.get("texto", "").upper().split("|")
            self.tit = [capa_texto(l.strip(), f, hexa(st.get("color", "#FFFFFF")), 0.5, 14) for l in lineas if l.strip()]

    def _frame_video(self, n_rel, fps):
        if self.proc is None:
            self.proc = subprocess.Popen(["ffmpeg", "-v", "error", "-i", self.ruta, "-vf",
                                          f"scale={self.W}:{self.H}:force_original_aspect_ratio=increase,crop={self.W}:{self.H},fps={fps}",
                                          "-an", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], stdout=subprocess.PIPE)
            self.leidos = 0
        while self.leidos <= n_rel:
            buf = self.proc.stdout.read(self.W * self.H * 3)
            if len(buf) < self.W * self.H * 3:
                break
            self.ultimo = Image.frombuffer("RGB", (self.W, self.H), buf)
            self.leidos += 1
        return self.ultimo

    def activo(self, t):
        return self.t0 <= t < self.t1

    def frame(self, t, fps):
        k = (t - self.t0) / max(0.01, self.t1 - self.t0)
        if self.modo == "video":
            fr = self._frame_video(int((t - self.t0) * fps), fps)
            return fr.convert("RGBA") if fr is not None else Image.new("RGBA", (self.W, self.H), (0, 0, 0, 255))
        if self.modo == "imagen":
            esc = 1.0 + 0.12 * k
            w, h = int(self.W * esc), int(self.H * esc)
            im = self.img.resize((w, h)) if (w, h) != self.img.size else self.img
            x, y = (im.width - self.W) // 2, (im.height - self.H) // 2
            return im.crop((x, y, x + self.W, y + self.H)).convert("RGBA")
        base = self.fondo.copy().convert("RGBA")
        total = sum(t_.height for t_ in self.tit) - 40 * max(0, len(self.tit) - 1)
        y = self.H * 0.42 - total / 2
        for i, ti in enumerate(self.tit):
            a = suave((t - self.t0 - i * 0.18) / 0.3)
            poner(base, ti, self.W / 2, y + ti.height / 2 + (1 - a) * 40, a)
            y += ti.height - 40
        return base

class Imagen:
    """Imagen del usuario (captura, producto, logo) que entra con rebote.
    marco: tarjeta (bordes redondeados + sombra) | celular (marco de teléfono) | nada."""
    def __init__(self, ev, W, H, plan, base_dir):
        self.ev, self.W, self.H = ev, W, H
        ruta = ev["archivo"] if os.path.isabs(ev["archivo"]) else os.path.join(base_dir, ev["archivo"])
        self.img = None
        if not os.path.exists(ruta):
            print(f"  [aviso] no encuentro la imagen {ruta}")
            return
        im = Image.open(ruta).convert("RGBA")
        self.fondo = None
        if ev.get("pantalla"):  # corte a pantalla completa: la imagen desenfocada de fondo + tarjeta al centro
            fb = cubrir(im.convert("RGB"), W // 6, H // 6).filter(ImageFilter.GaussianBlur(4)).resize((W, H), Image.BILINEAR)
            self.fondo = Image.alpha_composite(fb.convert("RGBA"), Image.new("RGBA", (W, H), (0, 0, 0, 110)))
        ancho = int(ev.get("ancho", 0.55) * W)
        im = im.resize((ancho, max(1, int(im.height * ancho / im.width))), Image.LANCZOS)
        marco = ev.get("marco", "tarjeta")
        if marco in ("tarjeta", "celular"):
            r = 70 if marco == "celular" else 36
            borde = 22 if marco == "celular" else 0
            w, h = im.width + borde * 2, im.height + borde * 2
            out = Image.new("RGBA", (w + 120, h + 120), (0, 0, 0, 0))
            sh = Image.new("L", out.size, 0)
            ImageDraw.Draw(sh).rounded_rectangle((60, 75, 60 + w, 75 + h), r, fill=170)
            out.paste((0, 0, 0, 255), (0, 0), sh.filter(ImageFilter.GaussianBlur(26)))
            if marco == "celular":
                ImageDraw.Draw(out).rounded_rectangle((60, 60, 60 + w, 60 + h), r, fill=(18, 18, 22, 255),
                                                      outline=(90, 90, 100, 255), width=3)
            m = Image.new("L", im.size, 0)
            ImageDraw.Draw(m).rounded_rectangle((0, 0, im.width - 1, im.height - 1), max(10, r - borde), fill=255)
            out.paste(im, (60 + borde, 60 + borde), m)
            im = out
        self.img = im
        self.cx = ev.get("x", 0.5) * W
        self.cy = ev.get("y", 0.3) * H

    def dibujar(self, base, t):
        if self.img is None:
            return
        ev = self.ev
        a = opacidad(t, ev["t0"], ev["t1"], 0.12, 0.25)
        if a <= 0:
            return
        if self.fondo is not None:
            if a >= 0.999:
                base.paste(self.fondo)
            else:
                base.alpha_composite(Image.blend(Image.new("RGBA", base.size, (0, 0, 0, 0)), self.fondo, a))
        e = (t - ev["t0"]) / 0.35
        esc = 1.0 if e >= 1 else (0.6 + 0.48 * suave(e / 0.7) if e < 0.7 else 1.08 - 0.08 * suave((e - 0.7) / 0.3))
        img = self.img if abs(esc - 1) < 0.01 else self.img.resize((int(self.img.width * esc), int(self.img.height * esc)))
        if ev.get("giro"):
            img = img.rotate(ev["giro"], resample=Image.BICUBIC, expand=True)
        poner(base, img, self.cx, self.cy + (1 - suave(min(1, e))) * 40, a)

# ---------------------------------------------------------------- zoom y transiciones
def zoom_en(t, zooms):
    z = 1.0
    for zm in zooms:
        t0, dur, a = zm["t"], zm.get("dur", 1.0), zm.get("escala", 1.1)
        if zm.get("modo", "golpe") == "golpe":  # salto inmediato, regreso suave
            if t0 <= t <= t0 + dur:
                z = max(z, a)
            elif t0 + dur < t <= t0 + dur + 0.25:
                z = max(z, a - (a - 1) * suave((t - t0 - dur) / 0.25))
        else:  # empuje continuo
            if t0 <= t <= t0 + dur:
                z = max(z, 1 + (a - 1) * suave((t - t0) / dur))
            elif t0 + dur < t <= t0 + dur + 0.4:
                z = max(z, a - (a - 1) * suave((t - t0 - dur) / 0.4))
    return z

def aplicar_zoom(img, z, foco):
    if z <= 1.001:
        return img
    W, H = img.size
    w, h = W / z, H / z
    cx = min(max(foco[0] * W, w / 2), W - w / 2)
    cy = min(max(foco[1] * H, h / 2), H - h / 2)
    return img.resize((W, H), Image.BICUBIC, box=(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2))

class Transiciones:
    def __init__(self, evs, W, H):
        self.evs = evs
        self.W, self.H = W, H
        # banda diagonal de luz
        L = int(math.hypot(W, H)) + 200
        band = np.zeros((L, L), np.float32)
        x = np.arange(L) - L / 2
        prof = np.exp(-(x / 70.0) ** 2) + 0.35 * np.exp(-(x / 260.0) ** 2)
        band[:] = prof[None, :]
        self.band = Image.fromarray((np.clip(band, 0, 1) * 255).astype(np.uint8), "L").rotate(28, resample=Image.BILINEAR)
        self.L = L

    def aplicar(self, arr, t):
        out = arr
        for ev in self.evs:
            t0, dur = ev["t"], ev.get("dur", 0.45)
            if not (t0 <= t <= t0 + dur):
                continue
            k = (t - t0) / dur
            if ev["tipo"] == "destello":
                off = int((k - 0.5) * (self.W + 900))
                cx = self.L // 2 - off
                cy = self.L // 2
                crop = self.band.crop((cx - self.W // 2, cy - self.H // 2, cx - self.W // 2 + self.W, cy - self.H // 2 + self.H))
                m = np.asarray(crop, np.float32)[..., None] / 255.0
                pico = math.sin(math.pi * k)
                tinte = np.array(hexa(ev["color"])[:3], np.float32) / 255.0 if ev.get("color") else np.ones(3, np.float32)
                out = np.clip(out.astype(np.float32) + m * 255 * 0.85 * tinte + 40 * pico * pico * tinte, 0, 255).astype(np.uint8)
            elif ev["tipo"] == "flash":
                col = np.array(hexa(ev.get("color", "#2D6BFF"))[:3], np.float32)
                pico = math.sin(math.pi * k) ** 2 * ev.get("fuerza", 0.55)
                out = np.clip(out.astype(np.float32) * (1 - pico) + col * pico + 30 * pico, 0, 255).astype(np.uint8)
        return out

# ---------------------------------------------------------------- principal
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("palabras")
    ap.add_argument("plan")
    ap.add_argument("--salida")
    ap.add_argument("--desde", type=float, default=0)
    ap.add_argument("--hasta", type=float, default=0)
    ap.add_argument("--crf", default="18")
    a = ap.parse_args()

    plan = json.load(open(a.plan, encoding="utf-8"))
    palabras = json.load(open(a.palabras, encoding="utf-8"))["words"]
    W, H, fps, dur = probe(a.video)
    hasta = a.hasta or dur
    salida = a.salida or os.path.splitext(a.video)[0] + "." + plan.get("estilo", "v2") + ".mp4"

    cps = {}
    cpf = os.path.join(FUENTES, "MaterialSymbolsRounded.codepoints")
    if os.path.exists(cpf):
        for ln in open(cpf):
            p = ln.split()
            if len(p) == 2:
                cps[p[0]] = p[1]

    evs = plan.get("eventos", [])
    titulos = [Titulo(e, W, H, plan) for e in evs if e["tipo"] == "titulo"]
    acentos = [Acento(e, W, H, plan) for e in evs if e["tipo"] == "acento"]
    pasos = [Pasos(e, W, H, plan) for e in evs if e["tipo"] == "pasos"]
    tarjetas = [Tarjeta(e, W, H, plan, cps) for e in evs if e["tipo"] == "tarjeta"]
    pildoras = [Pildora(e, W, H, plan) for e in evs if e["tipo"] == "cta"]
    iconos = [Icono(e, W, H, plan, cps) for e in evs if e["tipo"] == "icono"]
    base_dir = os.path.dirname(os.path.abspath(a.plan))
    brolls = [BRoll(e, W, H, plan, base_dir) for e in evs if e["tipo"] == "broll"]
    imagenes = [Imagen(e, W, H, plan, base_dir) for e in evs if e["tipo"] == "imagen"]
    zooms = [e for e in evs if e["tipo"] == "zoom"]
    trans = Transiciones([e for e in evs if e["tipo"] in ("destello", "flash")], W, H)
    subs = Subtitulos(palabras, W, H, plan)
    subs.ocultar = subs.ocultar + [(p.ev["t0"], p.ev["t1"]) for p in pasos]
    recorte = Recorte(plan.get("mascara"))
    subs.ocultar = subs.ocultar + [(b.t0, b.t1) for b in brolls if not b.ev.get("subtitulos", True)]
    foco = plan.get("foco", [0.55, 0.38])

    g = plan.get("color", {})
    vf = []
    if g:
        vf.append("eq=contrast={c}:saturation={s}:brightness={b}:gamma={gm}".format(
            c=g.get("contraste", 1.0), s=g.get("saturacion", 1.0), b=g.get("brillo", 0.0), gm=g.get("gamma", 1.0)))
        if g.get("curvas"):
            vf.append("curves=" + g["curvas"])
        if g.get("viñeta"):
            vf.append("vignette=angle={}".format(g["viñeta"]))
    vf.append("format=rgb24")
    ent = ["ffmpeg", "-v", "error", "-ss", str(a.desde), "-to", str(hasta), "-i", a.video,
           "-vf", ",".join(vf), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    sal = ["ffmpeg", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(fps),
           "-i", "-", "-ss", str(a.desde), "-to", str(hasta), "-i", a.video, "-map", "0:v", "-map", "1:a?",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", a.crf, "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", salida]
    pin = subprocess.Popen(ent, stdout=subprocess.PIPE)
    pout = subprocess.Popen(sal, stdin=subprocess.PIPE)
    tam = W * H * 3
    n = 0
    while True:
        buf = pin.stdout.read(tam)
        if len(buf) < tam:
            break
        t = a.desde + n / fps
        arr = np.frombuffer(buf, np.uint8).reshape(H, W, 3)
        img = Image.fromarray(arr, "RGB")
        br = next((b for b in brolls if b.activo(t)), None)
        if br is not None:
            base = br.frame(t, fps)
        else:
            img = aplicar_zoom(img, zoom_en(t, zooms), foco)
            base = img.convert("RGBA")
        for p in pasos:
            p.fondo(base, t)
        for ti in titulos:
            if br is not None and ti.detras:
                ti_det = ti.detras; ti.detras = False
                ti.dibujar(base, t, recorte, n); ti.detras = ti_det
            else:
                ti.dibujar(base, t, recorte, n)
        for p in pasos:
            p.dibujar(base, t)
        for im_ in imagenes:
            im_.dibujar(base, t)
        subs.dibujar(base, t)
        for ac in acentos:
            ac.dibujar(base, t)
        for tj in tarjetas:
            tj.dibujar(base, t)
        for pl in pildoras:
            pl.dibujar(base, t)
        for ic in iconos:
            ic.dibujar(base, t)
        out = np.asarray(base.convert("RGB"))
        out = trans.aplicar(out, t)
        pout.stdin.write(np.ascontiguousarray(out).tobytes())
        n += 1
        if n % 150 == 0:
            print(f"  {t:5.1f}s / {hasta:.1f}s", flush=True)
    pout.stdin.close()
    pout.wait()
    pin.wait()
    print(f"OK {salida} ({n} cuadros)")

if __name__ == "__main__":
    main()
