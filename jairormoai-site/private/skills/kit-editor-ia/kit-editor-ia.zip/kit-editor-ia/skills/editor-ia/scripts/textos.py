"""Genera capas de texto (.ass) sincronizadas con la voz.

Modos:
  subtitulos  palabras.json  [--palabras-por-bloque 3] [--estilo karaoke|bloque|caja] [--posicion abajo|centro]
  gancho      palabras.json  --texto "LA FRASE" [--dur 2.6] [--inicio 0]
  checklist   palabras.json  --item "Paso uno" --item "Paso dos" ...   (cada item entra cuando lo dices)
  impacto     palabras.json  --palabra "GRATIS" [--dur 1.4]           (palabra gigante; con /fondo va detrás de ti)

Todos aceptan --res 1080x1920 y --salida capa.ass. Colores y tipografía de marca (Exo 2).
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from ek import AZUL, BLANCO, MAGENTA, NEGRO, ass_header, esc, load, norm, ts_ass

ap = argparse.ArgumentParser()
ap.add_argument("modo", choices=["subtitulos", "gancho", "checklist", "impacto"])
ap.add_argument("palabras")
ap.add_argument("--res", default=None)
ap.add_argument("--salida")
ap.add_argument("--palabras-por-bloque", type=int, default=3)
ap.add_argument("--estilo", default="karaoke", choices=["karaoke", "bloque", "caja"])
ap.add_argument("--posicion", default="abajo", choices=["abajo", "centro"])
ap.add_argument("--texto"); ap.add_argument("--palabra")
ap.add_argument("--item", action="append", default=[])
ap.add_argument("--dur", type=float, default=None)
ap.add_argument("--inicio", type=float, default=0.0)
ap.add_argument("--mayusculas", action="store_true")
ap.add_argument("--y", type=float, default=0.30, help="altura de la palabra de impacto (0 arriba, 1 abajo)")
a = ap.parse_args()

d = load(a.palabras)
words = d["words"]
if a.res:
    W, H = map(int, a.res.lower().split("x"))
else:
    try:
        from ek import probe
        p = probe(d["video"]); W, H = p["w"], p["h"]
    except Exception:
        W, H = 1080, 1920
k = W / 1080.0
fs = lambda n: int(n * k)
mv_sub = int(H * (0.28 if a.posicion == "abajo" else 0.45))

styles = [
    f"Style: Sub,Exo 2 Black,{fs(78)},{BLANCO},{MAGENTA},{NEGRO},&H64000000,-1,0,0,0,100,100,0,0,1,{fs(7)},{fs(2)},2,{fs(60)},{fs(60)},{mv_sub},1",
    f"Style: Caja,Exo 2 Black,{fs(70)},{NEGRO},{MAGENTA},&H00FFFFFF,&H00FFFFFF,-1,0,0,0,100,100,0,0,3,{fs(18)},0,2,{fs(80)},{fs(80)},{mv_sub},1",
    f"Style: Gancho,Exo 2 Black,{fs(104)},{BLANCO},{MAGENTA},{NEGRO},&H50000000,-1,0,0,0,100,100,-1,0,1,{fs(9)},{fs(3)},8,{fs(70)},{fs(70)},{int(H*0.12)},1",
    f"Style: Check,Exo 2 Black,{fs(56)},{NEGRO},{AZUL},&H00FFFFFF,&H00FFFFFF,-1,0,0,0,100,100,0,0,3,{fs(16)},0,7,{fs(70)},{fs(70)},0,1",
    f"Style: Impacto,Exo 2 Black,{fs(300)},{MAGENTA},{MAGENTA},{MAGENTA},&H00000000,-1,0,0,0,100,100,-4,0,1,0,0,5,0,0,0,1",
]
ev = []
U = (lambda t: t.upper()) if a.mayusculas or a.modo in ("gancho", "impacto") else (lambda t: t)


def find_time(text):
    """Primer momento en que se dice 'text' (busca por palabras normalizadas)."""
    target = norm(text).split()
    if not target:
        return None
    ws = [norm(w["w"]) for w in words]
    for i in range(len(ws)):
        if ws[i] == target[0] or (len(target[0]) > 3 and ws[i].startswith(target[0][:4])):
            return words[i]["s"]
    return None


if a.modo == "subtitulos":
    n = max(1, a.palabras_por_bloque)
    grupos, cur = [], []
    for w in words:
        if cur and (len(cur) >= n or w["s"] - cur[-1]["e"] > 0.6):
            grupos.append(cur); cur = []
        cur.append(w)
    if cur: grupos.append(cur)
    for gi, g in enumerate(grupos):
        s = g[0]["s"]
        e = g[-1]["e"] + 0.05
        if gi + 1 < len(grupos):
            e = min(max(e, grupos[gi + 1][0]["s"] - 0.01), grupos[gi + 1][0]["s"])
        if a.estilo == "karaoke":
            for wi, w in enumerate(g):  # una línea por palabra activa: la palabra dicha se ilumina
                ws_ = w["s"]; we_ = g[wi + 1]["s"] if wi + 1 < len(g) else e
                txt = " ".join(("{\\c" + MAGENTA + "\\fscx108\\fscy108}" + esc(U(x["w"])) + "{\\r}") if x is w else esc(U(x["w"])) for x in g)
                ev.append(f"Dialogue: 1,{ts_ass(ws_)},{ts_ass(we_)},Sub,,0,0,0,,{{\\fad(0,0)}}{txt}")
        else:
            st = "Caja" if a.estilo == "caja" else "Sub"
            txt = esc(U(" ".join(x["w"] for x in g)))
            ev.append(f"Dialogue: 1,{ts_ass(s)},{ts_ass(e)},{st},,0,0,0,,{{\\fad(60,0)}}{txt}")

elif a.modo == "gancho":
    if not a.texto:
        sys.exit("Falta --texto")
    s = a.inicio
    e = s + (a.dur or 2.6)
    txt = esc(a.texto.upper())
    ev.append(f"Dialogue: 2,{ts_ass(s)},{ts_ass(e)},Gancho,,0,0,0,,"
              f"{{\\fad(0,180)\\t(0,160,\\fscx100\\fscy100)\\fscx70\\fscy70\\blur0.6}}{txt}")

elif a.modo == "checklist":
    if not a.item:
        sys.exit("Falta al menos un --item")
    fin = d.get("dur", words[-1]["e"] if words else 10)
    y0 = int(H * 0.16); paso = fs(118)
    prev = 0.0
    for i, it in enumerate(a.item):
        t = find_time(it)
        t = t if t is not None else prev + 0.8
        prev = t
        y = y0 + i * paso
        ev.append(f"Dialogue: 3,{ts_ass(t)},{ts_ass(fin)},Check,,0,0,0,,"
                  f"{{\\pos({fs(70)},{y})\\fad(120,0)\\move({fs(20)},{y},{fs(70)},{y},0,160)}}{i+1:02d}  {esc(it)}")

elif a.modo == "impacto":
    if not a.palabra:
        sys.exit("Falta --palabra")
    t = find_time(a.palabra)
    t = t if t is not None else a.inicio
    e = t + (a.dur or 1.4)
    ev.append(f"Dialogue: 0,{ts_ass(t)},{ts_ass(e)},Impacto,,0,0,0,,"
              f"{{\\pos({W//2},{int(H*a.y)})\\fad(0,150)\\fscx60\\fscy60\\t(0,140,\\fscx100\\fscy100)}}{esc(a.palabra.upper())}")

out = a.salida or os.path.splitext(a.palabras)[0].replace(".palabras", "") + f".{a.modo}.ass"
with open(out, "w", encoding="utf-8") as f:
    f.write(ass_header(W, H, styles) + "\n".join(ev) + "\n")
print(f"OK {len(ev)} eventos -> {out}")
