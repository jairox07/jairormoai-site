"""Agrega música que baja sola cuando hablas (ducking) y efectos de sonido en momentos exactos.

Uso: python musica.py video.mp4 [--musica pista.mp3] [--volumen 0.22]
                      [--sfx whoosh.wav@0.0 --sfx pop.wav@3.2 ...] [--salida out.mp4]
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from ek import probe, run

ap = argparse.ArgumentParser()
ap.add_argument("video")
ap.add_argument("--musica"); ap.add_argument("--volumen", type=float, default=0.22)
ap.add_argument("--sfx", action="append", default=[], help="archivo@segundo")
ap.add_argument("--salida")
a = ap.parse_args()

info = probe(a.video)
dur = info["dur"]
ins = ["-i", a.video]
fc, mix = [], []
idx = 1
voz = "[0:a]" if info["audio"] else None
if voz:
    fc.append("[0:a]asplit=2[voz][key]")
if a.musica:
    ins += ["-stream_loop", "-1", "-i", a.musica]
    fc.append(f"[{idx}:a]atrim=0:{dur},volume={a.volumen},afade=t=out:st={max(0,dur-1.2)}:d=1.2[mus]")
    if voz:
        fc.append("[mus][key]sidechaincompress=threshold=0.03:ratio=8:attack=20:release=350[duck]")
        mix.append("[duck]")
    else:
        mix.append("[mus]")
    idx += 1
for s in a.sfx:
    f, t = s.rsplit("@", 1)
    ins += ["-i", f]
    ms = int(float(t) * 1000)
    fc.append(f"[{idx}:a]adelay={ms}|{ms},volume=0.8[s{idx}]")
    mix.append(f"[s{idx}]"); idx += 1
if voz:
    mix.insert(0, "[voz]")
if not mix:
    sys.exit("Nada que mezclar: da --musica o --sfx")
fc.append("".join(mix) + f"amix=inputs={len(mix)}:duration=first:normalize=0,alimiter=limit=0.95[a]")
out = a.salida or os.path.splitext(a.video)[0] + ".musica.mp4"
run(["ffmpeg", "-y", "-v", "error", *ins, "-filter_complex", ";".join(fc),
     "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-t", str(dur), out])
print(f"OK {out}")
