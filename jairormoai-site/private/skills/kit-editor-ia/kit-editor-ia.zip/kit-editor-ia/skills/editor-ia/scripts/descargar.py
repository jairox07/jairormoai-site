"""Baja un video de referencia desde un link (Reels, TikTok, YouTube Shorts) SOLO para estudiar su estilo.

Uso: python descargar.py "https://..." [--salida referencia.mp4]
No se publica ni se reutiliza el video: se usa para sacar una hoja de cuadros (analizar.py referencia)
y crear un estilo propio. Respeta los derechos del creador: copia el estilo, no el contenido.
"""
import argparse, os, sys

ap = argparse.ArgumentParser()
ap.add_argument("url")
ap.add_argument("--salida", default="referencia.mp4")
a = ap.parse_args()

try:
    import yt_dlp
except ImportError:
    sys.exit("[kit-editor-ia] Falta yt-dlp. Corre el instalador del kit otra vez, o: pip install yt-dlp")

base = os.path.splitext(a.salida)[0]
opts = {"outtmpl": base + ".%(ext)s", "format": "mp4/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best",
        "merge_output_format": "mp4", "quiet": True, "no_warnings": True, "noplaylist": True}
try:
    with yt_dlp.YoutubeDL(opts) as y:
        info = y.extract_info(a.url, download=True)
except Exception as e:
    msg = str(e).lower()
    pista = ("Ese link pide iniciar sesión (pasa mucho con Instagram)." if "login" in msg or "cookie" in msg
             else "No pude bajarlo desde ese link.")
    sys.exit(f"[kit-editor-ia] {pista} Pide al usuario que guarde el video o haga una grabación de pantalla "
             f"y lo arrastre aquí. Detalle: {str(e)[:200]}")
ruta = base + ".mp4"
if not os.path.exists(ruta):
    cand = [f for f in os.listdir(os.path.dirname(os.path.abspath(base)) or ".") if f.startswith(os.path.basename(base) + ".")]
    ruta = cand[0] if cand else ruta
print(f"OK {ruta} · «{(info or {}).get('title', '')[:80]}» · {(info or {}).get('uploader', '')}")
