"""Revisa que la computadora tenga todo lo necesario para el Kit Editor IA."""
import importlib.util, platform, shutil, sys

ok = True
def check(nombre, cond, como):
    global ok
    print(("  ✓ " if cond else "  ✗ ") + nombre + ("" if cond else f"  →  {como}"))
    ok = ok and cond

mac = platform.system() == "Darwin"
print(f"Kit Editor IA · {platform.system()} {platform.machine()} · Python {sys.version.split()[0]}")
check("Python 3.10+", sys.version_info >= (3, 10), "instala Python desde python.org")
check("ffmpeg", bool(shutil.which("ffmpeg")), "brew install ffmpeg" if mac else "winget install Gyan.FFmpeg")
check("ffprobe", bool(shutil.which("ffprobe")), "viene con ffmpeg")
for mod, pipn in [("faster_whisper", "faster-whisper"), ("rembg", '"rembg[cpu]"'), ("PIL", "pillow"), ("numpy", "numpy")]:
    check(pipn, importlib.util.find_spec(mod) is not None, f"pip install {pipn}")
import os
base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
check("estilos v2 (7 plantillas)", len([f for f in os.listdir(os.path.join(base, "estilos")) if f.endswith(".json")]) >= 7,
      "vuelve a correr el instalador del kit")
check("tipografías del kit", os.path.exists(os.path.join(base, "fonts", "Anton-Regular.ttf")), "vuelve a correr el instalador del kit")
y = importlib.util.find_spec("yt_dlp") is not None
print(("  ✓ " if y else "  · ") + "yt-dlp (opcional, para links de referencia)" + ("" if y else "  →  pip install yt-dlp"))
print("\nTodo listo para editar." if ok else "\nFalta instalar lo marcado con ✗.")
