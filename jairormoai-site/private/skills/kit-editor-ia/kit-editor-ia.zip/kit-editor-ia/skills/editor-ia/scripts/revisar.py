"""Revisa que la computadora tenga todo lo necesario para el Kit Editor IA."""
import importlib.util, platform, shutil, sys

ok = True
def check(nombre, cond, como):
    global ok
    print(("  ✓ " if cond else "  ✗ ") + nombre + ("" if cond else f"  →  {como}"))
    ok = ok and cond

mac = platform.system() == "Darwin"
print(f"Kit Editor IA · {platform.system()} {platform.machine()} · Python {sys.version.split()[0]}")
check("Python 3.10+", sys.version_info >= (3, 10), "instala Python desde python.org")
check("ffmpeg", bool(shutil.which("ffmpeg")), "brew install ffmpeg" if mac else "winget install Gyan.FFmpeg")
check("ffprobe", bool(shutil.which("ffprobe")), "viene con ffmpeg")
for mod, pipn in [("faster_whisper", "faster-whisper"), ("rembg", '"rembg[cpu]"'), ("PIL", "pillow"), ("numpy", "numpy")]:
    check(pipn, importlib.util.find_spec(mod) is not None, f"pip install {pipn}")
print("\nTodo listo para editar." if ok else "\nFalta instalar lo marcado con ✗.")
