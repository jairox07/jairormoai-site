"""Decide qué partes del video se quedan: quita pausas, muletillas y tomas repetidas.

Uso: python planear_cortes.py palabras.json [--pausa 0.45] [--sin-tomas] [--sin-muletillas]
                                [--quitar "texto exacto a quitar"] [--salida plan.json]
Salida plan.json: {"keep": [[s,e],...], "frases": [...], "quitadas": [...]}
Claude revisa "frases" y "quitadas" antes de aplicar y puede editar el plan a mano.
"""
import argparse, difflib, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from ek import load, norm, save

MULETILLAS = {"eh", "ehh", "em", "emm", "mmm", "mm", "este", "o sea", "ah", "aja"}

ap = argparse.ArgumentParser()
ap.add_argument("palabras")
ap.add_argument("--pausa", type=float, default=0.45, help="silencio mínimo (s) que se corta")
ap.add_argument("--margen", type=float, default=0.08, help="aire que se deja antes/después de cada frase")
ap.add_argument("--sin-tomas", action="store_true", help="no buscar tomas repetidas")
ap.add_argument("--sin-muletillas", action="store_true")
ap.add_argument("--quitar", action="append", default=[], help="frase a eliminar (se puede repetir)")
ap.add_argument("--salida")
a = ap.parse_args()

d = load(a.palabras)
words = [w for w in d["words"]]
if not a.sin_muletillas:
    words = [w for w in words if norm(w["w"]) not in MULETILLAS]

# 1) Agrupar en frases separadas por silencios o por puntuación final
frases, cur = [], []
for i, w in enumerate(words):
    if cur and (w["s"] - cur[-1]["e"] > a.pausa):
        frases.append(cur); cur = []
    cur.append(w)
    if w["w"].rstrip().endswith((".", "?", "!")) and i + 1 < len(words) and words[i + 1]["s"] - w["e"] > 0.2:
        frases.append(cur); cur = []
if cur:
    frases.append(cur)

def texto(f):
    return " ".join(x["w"] for x in f)

quitadas = []
viva = [True] * len(frases)

# 2) Tomas repetidas: si una frase se parece al arranque de alguna de las 3 siguientes, gana la última
if not a.sin_tomas:
    for i in range(len(frases)):
        ti = norm(texto(frases[i]))
        if len(ti.split()) < 2:
            continue
        for j in range(i + 1, min(i + 4, len(frases))):
            tj = norm(texto(frases[j]))
            head = " ".join(tj.split()[: len(ti.split()) + 1])
            r = difflib.SequenceMatcher(None, ti, head).ratio()
            if r >= 0.62 or (len(ti) > 6 and tj.startswith(ti[: max(6, len(ti) // 2)])):
                viva[i] = False
                quitadas.append({"frase": texto(frases[i]), "motivo": f"toma repetida (se queda la #{j+1})"})
                break

# 3) Frases que el usuario pidió quitar
for q in a.quitar:
    nq = norm(q)
    for i, f in enumerate(frases):
        if viva[i] and nq and nq in norm(texto(f)):
            viva[i] = False
            quitadas.append({"frase": texto(f), "motivo": "pedido del usuario"})

keep = []
for i, f in enumerate(frases):
    if not viva[i]:
        continue
    s = max(0.0, f[0]["s"] - a.margen); e = min(d["dur"], f[-1]["e"] + a.margen)
    if keep and s <= keep[-1][1] + 0.05:
        keep[-1][1] = e
    else:
        keep.append([round(s, 3), round(e, 3)])

total = sum(e - s for s, e in keep)
out = a.salida or a.palabras.replace(".palabras.json", "") + ".plan.json"
save({"keep": keep, "frases": [{"n": i + 1, "texto": texto(f), "queda": viva[i],
                                "s": f[0]["s"], "e": f[-1]["e"]} for i, f in enumerate(frases)],
      "quitadas": quitadas, "dur_original": d["dur"], "dur_final": round(total, 2)}, out)
print(f"OK {len(keep)} tramos · {d['dur']:.1f}s -> {total:.1f}s -> {out}")
for q in quitadas:
    print(f"  - quitada: «{q['frase']}» ({q['motivo']})")
