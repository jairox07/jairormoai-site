# Kit Editor IA v2 · jairoromo.ai

**Tú grabas. Claude edita.** Son 12 editores, un asistente guiado (/editar) y **7 estilos con diseño completo** que convierten a Claude Code en tu editor de video. Grabas como te salga, se lo mandas y le pides en español lo que quieres.

**Nuevo en v2 · estilos:** Cine Premium, Notificación, Negocios Bold, Podcast Minimal, Reto / Energía, Explicador y Neón de marca (mira `skills/editor-ia/estilos/catalogo.jpg`). Todos traen B-roll inicial, texto gigante detrás de ti al abrir y al cerrar, íconos en lo importante, zooms y transiciones. Y puedes crear **tu propio estilo** a partir de un video o link que te guste.

| Comando | Qué hace |
|---|---|
| `/corte` | Quita pausas, muletillas y errores |
| `/toma` | Si repetiste una frase, se queda con la mejor toma |
| `/subtitulos` | Subtítulos palabra por palabra, sincronizados con tu voz |
| `/gancho` | Frase grande en pantalla en los primeros 2 segundos |
| `/checklist` | Cada punto entra justo cuando lo dices |
| `/fondo` | Te recorta sin pantalla verde y te pone otro escenario |
| `/impacto` | Palabra gigante detrás de ti |
| `/musica` | Música que baja sola cuando hablas, más efectos de sonido |
| `/estilos` | Te enseña el catálogo de estilos con imágenes |
| `/referencia` | Crea tu propio estilo desde un video o link que te guste y lo guarda |
| `/editar` | Asistente: te pregunta estilo, B-roll, gancho y cierre, y edita |
| `/prueba` | Revisa la edición antes de entregártela |
| `editor-ia` | El editor principal: entiende tu pedido y combina todo lo anterior |

Todo corre **en tu computadora**: ffmpeg, Whisper para la transcripción y rembg para el recorte. Tu video no se sube a ningún lado.

- Instalación: abre **MANUAL.pdf** (o pídele a Claude que lea INSTALAR.md)
- Pedidos listos para copiar: [PEDIDOS.md](PEDIDOS.md)

Precio: US$19, pago único · Hecho por Jairo Romo · [Agenda una sesión 1:1](https://jairoromoai.novotech.mx/sessions)

Licencia de uso personal: no se permite revender ni redistribuir. Las tipografías e íconos incluidos son de licencia libre (ver `skills/editor-ia/fonts/LICENCIAS.md`).
