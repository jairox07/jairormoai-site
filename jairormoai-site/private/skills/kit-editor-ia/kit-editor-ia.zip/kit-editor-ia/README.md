# Kit Editor IA · jairoromo.ai

**Tú grabas. Claude edita.** Son 11 editores, más un modo guiado (/editar), que convierten a Claude Code en tu editor de video. Grabas como te salga, se lo mandas y le pides en español lo que quieres.

| Comando | Qué hace |
|---|---|
| `/corte` | Quita pausas, muletillas y errores |
| `/toma` | Si repetiste una frase, se queda con la mejor toma |
| `/subtitulos` | Subtítulos palabra por palabra, sincronizados con tu voz |
| `/gancho` | Frase grande en pantalla en los primeros 2 segundos |
| `/checklist` | Cada punto entra justo cuando lo dices |
| `/fondo` | Te recorta sin pantalla verde y te pone otro escenario |
| `/impacto` | Palabra gigante detrás de ti |
| `/musica` | Música que baja sola cuando hablas, más efectos de sonido |
| `/referencia` | Copia el ritmo y estilo de un Reels que te guste |
| `/prueba` | Revisa la edición antes de entregártela |
| `editor-ia` | El editor principal: entiende tu pedido y combina todo lo anterior |

Todo corre **en tu computadora**: ffmpeg, Whisper para la transcripción y rembg para el recorte. Tu video no se sube a ningún lado.

- Instalación: abre **MANUAL.pdf** (o pídele a Claude que lea INSTALAR.md)
- Pedidos listos para copiar: [PEDIDOS.md](PEDIDOS.md)

Precio: US$19, pago único · Hecho por Jairo Romo · [Agenda una sesión 1:1](https://jairoromoai.novotech.mx/sessions)

Licencia de uso personal: no se permite revender ni redistribuir. Exo 2 se incluye bajo la licencia SIL Open Font License.
