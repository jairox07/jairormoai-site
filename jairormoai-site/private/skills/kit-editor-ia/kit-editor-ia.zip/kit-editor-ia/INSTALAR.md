# Instalar el Kit Editor IA (instrucciones para Claude)

Claude: el usuario compró el Kit Editor IA y quiere que lo instales en esta computadora. Esta carpeta es el kit descomprimido. El manual para personas está en MANUAL.pdf.

## Pasos
1. Detecta el sistema operativo.
2. Corre el instalador desde ESTA carpeta, con la ruta entre comillas porque puede tener espacios:
   - **Windows:** `powershell -ExecutionPolicy Bypass -File "<ruta de esta carpeta>/instalar.ps1"`
   - **Mac:** `bash "<ruta de esta carpeta>/instalar.sh"`
3. El instalador tarda de 5 a 15 minutos (descarga ffmpeg, Python y paquetes). Usa un tiempo de espera largo y no lo interrumpas.
4. Al terminar, confirma con `bash ~/.kit-editor-ia/kit revisar`: todo debe salir con ✓.
5. Dile al usuario, en lenguaje simple:
   - Que cierre y vuelva a abrir Claude Code una vez, para que se carguen los 11 editores (/corte, /subtitulos, etc.).
   - Que grabe un video vertical hablado de 20 a 90 s, lo arrastre al chat y pida: «Edítame este video».

## Si algo falla
- **Mac sin Homebrew:** el instalador muestra un comando. El usuario debe pegarlo él mismo en la app Terminal, porque pide su contraseña. Explícaselo y, cuando termine, vuelve a correr el instalador.
- **Windows sin winget:** pide al usuario actualizar "Instalador de aplicación" desde Microsoft Store, o instalar Python 3.12 desde python.org (con "Add python.exe to PATH") y ffmpeg. Luego vuelve a correr el instalador.
- **Windows, Python recién instalado que no se detecta:** cierra y abre Claude Code, y vuelve a correr el instalador.

Soporte o instalación acompañada: https://jairoromoai.novotech.mx/sessions
