#!/usr/bin/env bash
# Kit Editor IA · jairoromo.ai · instalador para Mac (también sirve en Linux)
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.claude/skills"
HOMEKIT="$HOME/.kit-editor-ia"

echo "== Kit Editor IA · instalación =="
echo "→ 1/4 Copiando los 11 editores a $DEST"
mkdir -p "$DEST" "$HOMEKIT"
for s in "$DIR"/skills/*/; do
  n=$(basename "$s"); rm -rf "$DEST/$n"; cp -R "$s" "$DEST/$n"; echo "   ✓ /$n"
done
cp "$DIR/skills/editor-ia/kit.sh" "$HOMEKIT/kit"; chmod +x "$HOMEKIT/kit"

echo "→ 2/4 Revisando ffmpeg y Python"
if [ "$(uname)" = "Darwin" ] && ! command -v brew >/dev/null 2>&1; then
  echo ""
  echo "✗ Falta Homebrew (el instalador de programas de Mac). Abre la app Terminal, pega esta línea y escribe tu contraseña de la Mac:"
  echo '  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"'
  echo "Cuando termine, vuelve a correr este instalador."
  exit 1
fi
command -v ffmpeg >/dev/null 2>&1 || { echo "   instalando ffmpeg…"; brew install ffmpeg; }

PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)' 2>/dev/null; then PY="$c"; break; fi
done
if [ -z "$PY" ]; then echo "   instalando Python 3.12…"; brew install python@3.12; PY=python3.12; fi
echo "   ✓ ffmpeg · ✓ $($PY --version)"

echo "→ 3/4 Creando el entorno del kit en $HOMEKIT/venv (tarda 2-5 min la primera vez)"
"$PY" -m venv "$HOMEKIT/venv"
"$HOMEKIT/venv/bin/python" -m pip install --upgrade pip -q
"$HOMEKIT/venv/bin/python" -m pip install -q faster-whisper "rembg[cpu]" pillow numpy

echo "→ 4/4 Revisión final"
bash "$HOMEKIT/kit" revisar
echo ""
echo "Listo. En Claude Code arrastra tu video y escribe: «Edítame este video»."
